Directories��
0.01��maximum allowed N uptake by plants was set to 1%
0.05��maximum allowed N uptake by plants was set to 5%

Files��
AdsorbCs and AdsorbNs: Adsorbable C and N pools
AvailCs and AvailNs: Available C and N pools
BACr and BANr: Active microbial biomass fraction for C and N
BACs and BANs: Active microbial biomass  C and N
BDCs and BDNs: Active microbial biomass C and N
BC and BN: Total microbial biomass C and N
BCN: Microbial biomass C:N ratio
BCr: Fraction microbial biomass carbon in soil organic carbon
EC and EN: Total nzyme C and N
ECr and ENr: Ratio of enzyme C and N to microbial biomass C and N, respectively
EFCs and EFNs: Enzymes decomposing fresh organic matter (litter) extracting C and N, respectively
ESCs and ESNs: Enzymes decomposing soil organic matter (litter) extracting C and N, respectively
LMCs and LMNs: Metabolic litter C and N
LSCs and LSNs: Structrural litter C and N
SACs and SANs: Active soil organic C and N
SSCs and SSNs: Slow soil organic C and N
SPCs and SPNs: Passive soil organic C and N
SC and SN: Soil organic C and N (active + slow + passive)
R: Total respiration
