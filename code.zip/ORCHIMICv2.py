#!/usr/bin/env python
#PBS -N ORCHIMICv2.0
#PBS -j oe
#PBS -q long
#PBS -o oe.ORCHIMICv2.0
#PBS -l nodes=1:ppn=1

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import time
import sys
from scipy.optimize import minimize
import random
import scipy.stats as st

OK_func='y'
#def run(vers,OK_N,OK_N_ENZ,OK_absorb_N,start_gridid,N_gridid,ts,RLRS_method):
OK_func='n' #set to 'n' to do test and add # at the begin of the above line
if OK_func=='n':  #if OK_func=='y', add # at the begin of this line 
  starttime=time.time()
  #path for output
  #outdir0='/home/surface4/yhuang/microbe/'
  outdir0='/ccc/scratch/cont003/gen6328/huangy/microbe/'
  
  #some flags for test simulation
  OK_test='y'
  OK_check='n'
  if OK_check=='y':
    OK_print='y'
  else:
    OK_print='n'
  
  #use constant CUE
  OK_constant_CUE='y'
  
  #temperature sensitive or not for the following paramters?
  OK_fixed_dMFT='n'
  OK_fixed_dENZ='n'
  OK_fixed_KM='n'
  OK_fixed_Km='n'
  
  ##Control flags
  ##simulations
  if OK_func=='n':
    #activate N dynamics
    OK_N='y'
    ts=24 #time step, hours
    #with enzyme specific for N
    OK_N_ENZ='y'
    #consider adsorption for N
    OK_absorb_N='y'

    #two method to track FOM-derived C in each pool
    #1: the fraction of FOM-derived C in uptake flux is equal to that of the Avail pool after considering decomposition fluxex
    #2: the microbes will use new decomposed C fluxes first
    RLRS_method=1 
   
    vers='test'
    if OK_N=='y':
        vers='CN_'+vers
    elif OK_N=='n':
        vers='C_'+vers
  
    vers=vers+'_m'+str(RLRS_method)    

    if OK_N_ENZ=='y':
      vers=vers+'_ECN'
    elif OK_N_ENZ=='n':
      vers=vers+'_EC'
    
    if OK_absorb_N=='y':
      vers=vers+'_AbsCN'
    elif OK_absorb_N=='n':
      vers=vers+'_AbsC'
  
    start_gridid=99
    N_gridid=1
  else:
   OK_test='n'
   OK_check='n'
   OK_print='n'
  
  #molar mass for C, N and P
  global N
  N=1
  
  MMC=12.011
  MMN=14.007
  MMP=30.973761998
  
  global rMtoS
  global Actf
  global Slof
  global Pasf
  
  #minimum value prescribed in this model
  zerol=1.e-5
  #define function 
  def microbe_growth(ts,OK_N,OK_N_ENZ,OK_absorb_N,K_CAE,VmaxUptake_refin,Kdin,dMFTref,Kein,Km_ref,b,dENZ,VmaxLMC,KMLC,Ea_stab,Ea_mob,EaGL,EaKM,EaLM,EaLS,VmaxSSC,KMSC,EaSS,StabCmax,KdesC,KabsC,CAE,Adj_GL,Adj_LS,Adj_SA,Adj_SP,Ke_min,Ea_uptake,Ea_main,EaSA,EaSP,KM_uptakein,ELrin,pH0,T0,H0,pHs,Ts,Hs,pH0_dec,pHs_dec,KlossC,KlossN,KlossN2,LCin,LLfin,LCNin,AvailCin,AvailNin,GL,LMC,LMN,LSC,LSN,LLf,SAC,SAN,SSC,SSN,SPC,SPN,AvailC,AvailN,StabC,StabN,BA,BAN,BD,BDN,MFTtype,BCN,EFC,ESC,EFN,ESN,ECNin,OK_control,OK_constant_CUE,OK_stab_C,T,H,pH,clay,mn,sC,sN,AvailCLr,AvailCSr,StabCLr,StabCSr,SACLr,SACSr,SSCLr,SSCSr,SPCLr,SPCSr,BALr,BASr,BDLr,BDSr,EFCLr,EFCSr,ESCLr,ESCSr,EFNLr,EFNSr,ESNLr,ESNSr,LMtoSS,LStoSS,SStoSP,SAtoSP,expc,efLS,efSA,efSS,efSP,KCN,CUEpre,NUEpre,KMED,OK_plant_uptake_N,Nplant,Nuptakef,expuptake,BCNoptin,BCNminin,BCNmaxin,T_ref,OK_fixed_dMFT,OK_fixed_dENZ,OK_fixed_KM,OK_fixed_Km,KMAED):
    #Noted that GL is a litter pool that is not used
    MFT_min=zerol #1.e-5 #mmol
    #T_ref=273.15+12.  #12 from Wang et al., 2013  #5 from Charlie Koven et al., 2009
    max_avail=0.95  #Kaier et al., 2015
    CAE_min=0.01
    CAE_max=0.85 #Six et al., 2006
    T_exp=T_ref
  
    #two paramter providing the lower and upper limits
    vmin=0.25
    vmax=1.-vmin
  
    #transform molar ratio to mass ratio
    ECN=ECNin*MMC/MMN
    BCNopt=BCNoptin*MMC/MMN
    BCNmin=BCNminin*MMC/MMN
    BCNmax=BCNmaxin*MMC/MMN
  
    if OK_check=='y':
      if np.isnan(LLf):
        print 'Error: Nan in LLf'
        if OK_print=='y':
          print 'LLf',LLf
        sys.exit()
 
    #adjust paramter values according to time step actually used  
    VmaxUptake_refin=VmaxUptake_refin*ts
    Kdin          =Kdin*ts
    dMFTref       =dMFTref*ts
    Kein          =Kein*ts
    Km_ref        =Km_ref*ts
    dENZ          =dENZ*ts
    VmaxLMC       =VmaxLMC*ts
    VmaxSSC       =VmaxSSC*ts
    KabsC         =KabsC*ts
    KdesC         =KdesC*ts
    KlossC        =KlossC*ts
    KlossN        =KlossN*ts
    
    AvailCin      =AvailCin*ts
    AvailNin      =AvailNin*ts
    LCin          =LCin*ts
    Nplant        =Nplant*ts 
   
  
    #this paramters are used to consider respiration during decomposition, but not used in currently version
    if efSS<efSP: efSS=efSP
    if efSA<efSS: efSA=efSS
    if efLS<efSS: efLS=efSS
    
    if OK_loss=='n':
      KlossC=0.
      KlossN=0.
      #KlossP=0.
  
    #temperature sensitive adsorption and desorption rate  
    KabsC=KabsC*np.exp((0.-Ea_stab)/0.008314/T)/np.exp((0.-Ea_stab)/0.008314/T_ref)
    KdesC=KdesC*np.exp((0.-Ea_mob)/0.008314/T)/np.exp((0.-Ea_mob)/0.008314/T_ref)
    
    SAtoSS=0.15+0.68*clay-SAtoSP  #Parton et al., 1987, but clay here actually means clay+silt content
    
    VmaxUptake_ref=VmaxUptake_refin*1.
    Kd=Kdin*1.
    dMFT_ref=dMFTref*1.
    Ke=Kein*1.
    
    #calculate Eeq preparing for enzymatic decompostion
    EFCeq=EFC*1.
    ESCeq=ESC*1.
    EFNeq=EFN*1.
    ESNeq=ESN*1.
    
    if np.size(LCin)==1:
      LMf=0.85-0.018*LLfin*LCNin #LCN is the mass ratio
  
      if LMf>(1.-LLfin):LMf=(1.-LLfin)
      if LMf<0.: LMf=0.
      LMCin=LCin*LMf
      LSCin=LCin-LMCin
      LLCin=LCin*LLfin
      LNin=LCin/LCNin
      if LCNin>9999: LNin=0. 
      LSNin=LSCin/150. #mass ratio?  CN ratio of structure litter is assummed to be 150 in Parton et al., 1987
      if LSNin>LNin: LSNin=LNin
      LMNin=LNin-LSNin
      if LMNin<0.: LMNin=0. #To avoid numerical error causing negative LMNin
    else:
      LMCin=0.; LSCin=0.; LMNin=0.; LSNin=0.;LLCin=0.
      for i in np.arange(np.size(LCin)):
        LCintmp=LCin[i]; LLfintmp=LLfin[i]; LCNintmp=LCNin[i]
        LMf=0.85-0.018*LLfintmp*LCNintmp #LCN is the mass ratio  /MMC*MMN  #LCN is molar ratio
        if LMf>(1.-LLfintmp):LMf=(1.-LLfintmp)
        if LMf<0.: LMf=0.
        LMCintmp=LCintmp*LMf
        LSCintmp=LCintmp-LMCintmp
        LMCin=LMCin+LMCintmp
        LSCin=LSCin+LSCintmp
        LLCin=LLCin+LCintmp*LLfintmp
        LNintmp=LCintmp/LCNintmp
        if LCNintmp>9999.:LNintmp=0.
        LSNintmp=LSCintmp/150. #mass ratio?  CN ratio of structure litter is assummed to be 150 in Parton et al., 1987
        if LSNintmp>LNintmp: LSNintmp=LNintmp
        LMNintmp=LNintmp-LSNintmp
        if LMNintmp<0.: LMNintmp=0.
        LMNin=LMNin+LMNintmp
        LSNin=LSNin+LSNintmp
  
    LLfout=(LSC*LLf+LLCin)/(LSC+LSCin)
    if (LSC+LSCin)==0.:LLfout=0.
  
    if OK_fixed_KM=='y':
      KM_adj=np.exp(-EaKM/0.008314/T_exp)/np.exp(-EaKM/0.008314/T_ref)
    else:
      KM_adj=np.exp(-EaKM/0.008314/T)/np.exp(-EaKM/0.008314/T_ref)
    
    #calculate decompostion
    #function descriping effects of soil moisture, pH, clay content and lignin content on decomposition rate
    #control_H_tmp=-1.1*H**2+2.4*H-0.29  #see /modipsl/modeles/MICT/src_parameters/constantes_var.f90 moist_coeff, src_stomate/stomate_litter.f90 moistfunc_result
    #control_H=np.max([0.25,np.min([1,control_H_tmp])])
    #use the new scheme consider water and O2 limitation, Ito and Oikawa, 2002 from Falloon et al., 2011
    control_H1=0.2+H/(0.15+H)
    control_H2=0.2+(1.-H)/(0.08+(1.-H))
    control_H=np.min([control_H1,control_H2,1])
    control_pH=np.exp(-(pH-pH0_dec)**2/pHs_dec**2)
    control_clay=1.-0.75*clay
    control_lignin=np.exp(-3.0*LLfout)
    
    GLeq_adj=1. #GL/(KMLC+GL)*Adj_GL*np.exp(-EaGL/0.008314/T)/np.exp(-EaGL/0.008314/T_ref)*control_H*control_pH*control_clay
    LMCeq_adj=1. #LMC/(KMLC+LMC)*1.*np.exp(-EaLM/0.008314/T)/np.exp(-EaLM/0.008314/T_ref)*control_H*control_pH
    LSCeq_adj=1. #LSC/(KMLC+LSC)*1./Adj_LS*np.exp(-EaLS/0.008314/T)/np.exp(-EaLS/0.008314/T_ref)*control_H*control_pH*control_lignin
    
    GLeq=GL*GLeq_adj
    LMCeq=LMC*LMCeq_adj
    LSCeq=LSC*LSCeq_adj
    LCeq=GLeq+LMCeq+LSCeq
    
    LNeq=LMN+LSN
    
    SACeq_adj=1. #SAC/(KMSC+SAC)*Adj_SA*np.exp(-EaSA/0.008314/T)/np.exp(-EaSA/0.008314/T_ref)*control_H*control_pH*control_clay
    SSCeq_adj=1. #SSC/(KMSC+SSC)*1.*np.exp(-EaSS/0.008314/T)/np.exp(-EaSS/0.008314/T_ref)*control_H*control_pH
    SPCeq_adj=1. #SPC/(KMSC+SPC)*1./Adj_SP*np.exp(-EaSP/0.008314/T)/np.exp(-EaSP/0.008314/T_ref)*control_H*control_pH
    
    SACeq=SAC*SACeq_adj
    SSCeq=SSC*SSCeq_adj
    SPCeq=SPC*SPCeq_adj
    SCeq=SACeq+SSCeq+SPCeq
    
    SNeq=SAN+SSN+SPN
    
    #decomposition of fresh organic matter
    dGL=GL/(KMLC*KM_adj+LCeq+EFCeq)*VmaxLMC*Adj_GL*np.exp(-EaGL/0.008314/T)/np.exp(-EaGL/0.008314/T_ref)*control_H*control_pH*control_clay*EFCeq
    tmp=GL #+GLin
    if dGL>tmp: dGL=tmp          
  
    dLMC=LMC/(KMLC*KM_adj+LCeq+EFCeq)*VmaxLMC*np.exp(-EaLM/0.008314/T)/np.exp(-EaLM/0.008314/T_ref)*control_H*control_pH*EFCeq
    tLMC=LMC+LMCin
    if dLMC>tLMC: dLMC=tLMC         
  
    if OK_check=='y':
      if np.isnan(dLMC):
        print 'Nan in dLMC'
        print 'LMC',LMC
        print '(KMLC*KM_adj+LCeq+EFCeq)',(KMLC*KM_adj+LCeq+EFCeq)
        print 'VmaxLMC',VmaxLMC
        print 'EFCeq',EFCeq
        sys.exit()
  
    dLSC=LSC/(KMLC*KM_adj+LCeq+EFCeq)*VmaxLMC/Adj_LS*np.exp(-EaLS/0.008314/T)/np.exp(-EaLS/0.008314/T_ref)*control_H*control_pH*control_lignin*EFCeq
    tLSC=LSC+LSCin
    if dLSC>tLSC: dLSC=tLSC          
  
    if OK_N_ENZ=='y':
      #KCN is a paramter adjustting paramters for C to those for N, set to 1 as default
      dLMN=LMN/(KMLC*KM_adj/KCN+LNeq+EFNeq)*VmaxLMC/KCN*np.exp(-EaLM/0.008314/T)/np.exp(-EaLM/0.008314/T_ref)*control_H*control_pH*EFNeq
      tLMN=LMN+LMNin
      if dLMN>tLMN: dLMN=tLMN
  
      dLSN=LSN/(KMLC*KM_adj/KCN+LNeq+EFNeq)*VmaxLMC/Adj_LS/KCN*np.exp(-EaLS/0.008314/T)/np.exp(-EaLS/0.008314/T_ref)*control_H*control_pH*control_lignin*EFNeq
      tLSN=LSN+LSNin
      if dLSN>tLSN: dLSN=tLSN
    else:
      dLMN=dLMC*(LMN+LMNin)/tLMC
      if tLMC<=0.: dLMN=0.
      dLSN=dLSC*(LSN+LSNin)/tLSC
      if tLSC<=0.: dLSN=0.
    
    if OK_check=='y':
      if dLMN<0.:
        print 'dLMN=',dLMN
        print 'LMN=',LMN
        print 'tLMN=',tLMN
        sys.exit()
    
    #decomposition of soil organic carbon
    dSAC=SAC/(KMSC*KM_adj+SCeq+ESCeq)*VmaxSSC*Adj_SA*np.exp(-EaSA/0.008314/T)/np.exp(-EaSA/0.008314/T_ref)*control_H*control_pH*control_clay*ESCeq
    if dSAC>SAC: dSAC=SAC #Note that this is true only when time step is relative small
    dSSC=SSC/(KMSC*KM_adj+SCeq+ESCeq)*VmaxSSC*np.exp(-EaSS/0.008314/T)/np.exp(-EaSS/0.008314/T_ref)*control_H*control_pH*ESCeq
    if dSSC>SSC: dSSC=SSC
    dSPC=SPC/(KMSC*KM_adj+SCeq+ESCeq)*VmaxSSC/Adj_SP*np.exp(-EaSP/0.008314/T)/np.exp(-EaSP/0.008314/T_ref)*control_H*control_pH*ESCeq
    if dSPC>SPC: dSPC=SPC
  
    if OK_N_ENZ=='y':
      dSAN=SAN/(KMSC*KM_adj/KCN+SNeq+ESNeq)*VmaxSSC*Adj_SA/KCN*np.exp(-EaSA/0.008314/T)/np.exp(-EaSA/0.008314/T_ref)*control_H*control_pH*control_clay*ESNeq
      if dSAN>SAN: dSAN=SAN
      dSSN=SSN/(KMSC*KM_adj/KCN+SNeq+ESNeq)*VmaxSSC/KCN*np.exp(-EaSS/0.008314/T)/np.exp(-EaSS/0.008314/T_ref)*control_H*control_pH*ESNeq
      if dSSN>SSN: dSSN=SSN
      dSPN=SPN/(KMSC*KM_adj/KCN+SNeq+ESNeq)*VmaxSSC/Adj_SP/KCN*np.exp(-EaSP/0.008314/T)/np.exp(-EaSP/0.008314/T_ref)*control_H*control_pH*ESNeq
      if dSPN>SPN: dSPN=SPN
    else:
      dSAN=dSAC*SAN/SAC
      if SAC<=0.: dSAN=0.
      dSSN=dSSC*SSN/SSC
      if SSC<=0.: dSSN=0.
      dSPN=dSPC*SPN/SPC
      if SPC<=0.: dSPN=0.
  
    KMFCE=(dGL+dLMC+dLSC)/EFCeq
    KMSCE=(dSAC+dSSC+dSPC)/ESCeq
    if EFCeq<=0.: KMFCE=zerol
    if ESCeq<=0.: KMSCE=zerol
    if OK_N_ENZ=='y':
      KMFNE=(dLMN+dLSN)/EFNeq
      KMSNE=(dSAN+dSSN+dSPN)/ESNeq
      if EFNeq<=0.: KMFNE=1.
      if ESNeq<=0.: KMSNE=1.
  
    if OK_check=='y' and KMSNE<0.:
      print 'Error: negative value for KMSNE, KMSNE=',KMSNE
      print 'KMSNE',KMSNE,'dSAN',dSAN,'dSSN',dSSN,'dSPN',dSPN,'ESNeq',ESNeq
      print 'SAN',SAN,'SNeq',SNeq,'control_H',control_H,'control_pH',control_pH,'control_clay',control_clay,'ESNeq',ESNeq
      sys.exit()
  
    #update AvailC pool for MFT's uptake
    CdecLM=(dLMC*(1-LMtoSS)+dGL)*efLS
    CdecLS=(dLSC*(1-LLfout)*(1.-LStoSS)+dLSC*LLfout*0.3)*efLS
    CdecSA=(dSAC*(1.-SAtoSS-SAtoSP))*efSA
    CdecSS=(dSSC*(1.-SStoSP))*efSS
    CdecSP=dSPC*efSP
    
    NdecLM=dLMN*(1-LMtoSS)
    NdecLS=dLSN*(1-LLfout)*(1.-LStoSS)+dLSN*LLfout*0.3
    NdecSA=dSAN*(1.-SAtoSS-SAtoSP)
    NdecSS=dSSN*(1.-SStoSP)
    NdecSP=dSPN
    
    #print 'HYcheck',CdecLM+CdecLS+CdecSA+CdecSS+CdecSP,NdecLM+NdecLS+NdecSA+NdecSS+NdecSP
    AvailCdec=CdecLM+CdecLS+CdecSA+CdecSS+CdecSP
    if AvailCdec>0.:
      AvailCdecLr=(CdecLM+CdecLS+CdecSA*SACLr+CdecSS*SSCLr+CdecSP*SPCLr)/AvailCdec
    elif AvailCdec==0:
      AvailCdecLr=0.          
  
    AvailNdec=(NdecLM+NdecLS+NdecSA+NdecSS+NdecSP)*(1.-KlossN2)
    
    if OK_check=='y':
      if np.isnan(AvailCdec):
        print 'CdecLM',CdecLM,'CdecLS',CdecLS,'CdecSA',CdecSA,'CdecSS',CdecSS,'CdecSP',CdecSP          
        print 'dLMC',dLMC,'LMtoSS',LMtoSS,'efLS',efLS
        sys.exit()
  
    #calculate death of microbe
    EaMFT=47.
    if OK_fixed_dMFT=='y':
        dMFT_adj_T=np.exp(-EaMFT/0.008314/T_exp)/np.exp(-EaMFT/0.008314/T_ref)
    else:
        dMFT_adj_T=np.exp(-EaMFT/0.008314/T)/np.exp(-EaMFT/0.008314/T_ref)
    dMFT=dMFT_ref*dMFT_adj_T*BA #np.sum(BA,axis=0)
    BAd=dMFT*BA
    if BAd>BA: BAd=BA          
  
    BANd=dMFT*BAN
    if BANd>BAN: BANd=BAN
    if OK_control=='y':
      if BA<MFT_min:
        BAd=0.; BANd=0.
  
    AvailCmicd=BAd*sC
    AvailNmicd=BANd*sN
    AvailCmicdL=BAd*BALr*sC
  
    AvailC_tmp=AvailC+AvailCmicd+AvailCin
    AvailN_tmp=AvailN+AvailNdec+AvailNmicd+AvailNin

    AvailCLr_tmp=(AvailC*AvailCLr+AvailCmicdL+AvailCin)/AvailC_tmp
    if AvailC_tmp<=0.: AvailCLr_tmp=0.          
  
    #update MFT pools and calculate respiration
    tmp1=-(T-T0)**2
    tmp2=Ts**2
    tmp3=tmp1/tmp2
    fT=np.exp(tmp3)
    
    fT0=np.exp(-Ea_uptake/0.008314/T)/np.exp(-Ea_uptake/0.008314/T_ref)	
    
    tmp1=-(H-H0)**2
    tmp2=Hs**2
    tmp3=tmp1/tmp2
    fH=np.exp(tmp3)
    
    tmp1=-(pH-pH0)**2
    tmp2=pHs**2
    tmp3=tmp1/tmp2
    fpH=np.exp(tmp3)
    
    if BAN>0.:
      BACNtmp=BA/BAN
    else:
      BACNtmp=BCNmax
    if BACNtmp<BCNmin: BACNtmp=BCNmin
    if BACNtmp>BCNmax: BACNtmp=BCNmax
  
    #assume total uptake of C and N is constant
    VmaxUptake=VmaxUptake_ref*fT*fH*fpH*fT0 #total uptake rate including C and N
    fC=BCNopt/CUEpre*(BCNopt/BACNtmp)**expuptake
    fN=1./NUEpre*(BACNtmp/BCNopt)**expuptake
    VmaxUptakeC=VmaxUptake*fC/(fC+fN)
    VmaxUptakeN=VmaxUptake*fN/(fC+fN)
    if OK_check=='y':
      if np.isnan(VmaxUptakeC):
        print 'Nan in VmaxUptakeC: VmaxUptakeC=',VmaxUptakeC,'VmaxUptakeN=',VmaxUptakeN
        print 'fC=',fC,'fN=',fN
        print 'BCNopt=',BCNopt,'CUEpre=',CUEpre,'BCNopt=',BCNopt,'BACNtmp=',BACNtmp,'expuptake=',expuptake
        print 'BA',BA,'BAN',BAN
        sys.exit()  
  
    fBA=BA
    
    KM_uptake_adj=VmaxUptake_ref/VmaxUptake_refin
    KMC_uptake=KM_uptakein*KM_uptake_adj*KM_adj
    KMN_uptake=KMC_uptake/KCN
    
    #they are not used
    saturation_level=AvailC/(KMAED*KM_adj+AvailC)
    saturation_level_N=AvailN/(KMAED*KM_adj*0.1+AvailN)
  
    tAvailC=AvailC_tmp+AvailCdec
    tAvailN=AvailN_tmp
    s1=AvailC/(KMC_uptake+AvailC)
    #s2=AvailN/(KMC_uptake*0.1+AvailN)
    s2=AvailN/(KMC_uptake+AvailN)
    Uptake =VmaxUptakeC*fBA*s1 #AvailC/(KMC_uptake+AvailC)   #saturation_level
    UptakeN=VmaxUptakeN*fBA*s2 #AvailN/(KMC_uptake*0.1+AvailN)   #saturation_level_N

    s0=s1*fC/(fC+fN)+s2*fN/(fC+fN)
  
    if OK_check=='y':
      if np.isnan(Uptake):
        print 'Nan in Uptake: Uptake=',Uptake,'UptakeN=',UptakeN
        print 'VmaxUptakeC=',VmaxUptakeC,'VmaxUptakeN=',VmaxUptakeN
        print 'fBA=',fBA
        print 'saturation_level=',saturation_level,'saturation_level_N=',saturation_level_N
        sys.exit()
  
    TUptake=Uptake #np.zeros((1,N))
    TUptakeN=UptakeN #np.zeros((1,N))

    TUptake_adj=TUptake*1.0
    if TUptake_adj>tAvailC*max_avail: TUptake_adj=tAvailC*max_avail
    if TUptake>0.:
      factor_adj=TUptake_adj/TUptake
    else:
      factor_adj=0.
    Uptake_adj=Uptake*factor_adj
    if OK_check=='y':
      if np.isnan(Uptake_adj):
        print 'Nan in Uptake_adj; Uptake_adj=',Uptake_adj
        print 'Uptake=',Uptake,'factor_adj=',factor_adj 
        sys.exit()         
  
    if RLRS_method==1:
        if tAvailC>0:
          TUptake_adj_Lr=(AvailC_tmp*AvailCLr_tmp+AvailCdec*AvailCdecLr)/tAvailC
        else:
          TUptake_adj_Lr=0.5
    elif RLRS_method==2:
        if TUptake_adj<=AvailCdec: TUptake_adj_Lr=AvailCdecLr
        if TUptake_adj>AvailCdec:
          if TUptake_adj>0.:
            TUptake_adj_Lr=((AvailCdec*AvailCdecLr+(TUptake_adj-AvailCdec)*AvailCLr_tmp)/TUptake_adj)
          else:
            TUptake_adj_Lr=0.5
    else:
        print 'Error: RLRS_method has not been defined'
        sys.exit()
    if TUptake_adj<=0.: TUptake_adj_Lr=0.         
  
    if np.isnan(TUptake_adj):
      print 'Error: Nan in TUptake_adj: TUptake_adj=',TUptake_adj
      print 'tAvailC=',tAvailC
      print 'TUptake=',TUptake
      print 'Uptake=',Uptake
      sys.exit()
  
    TUptakeN_adj=TUptakeN*1.0
    if TUptakeN_adj>tAvailN*max_avail: TUptakeN_adj=tAvailN*max_avail
    factor_adj_N=TUptakeN_adj/TUptakeN
    if TUptakeN<=0.: factor_adj_N=0.
    UptakeN_adj=UptakeN*factor_adj_N
    
    if OK_fixed_Km=='y':
        Km_adj=np.exp(-Ea_main/0.008314/T_exp)/np.exp(-Ea_main/0.008314/T_ref)
    else:
        Km_adj=np.exp(-Ea_main/0.008314/T)/np.exp(-Ea_main/0.008314/T_ref)
    Km=Km_ref*Km_adj		
    
    Rma=BA*Km*(b+s0) #(saturation_level*saturation_level_N)**0.5)
    tmp=BA+Uptake_adj-BAd
    if Rma>tmp: Rma=tmp          
  
    BAmain=Rma-Uptake_adj
    if BAmain<0.: BAmain=0.
    tmp=BA-BAd
    if BAmain>tmp: BAmain=tmp
  
    BAmainN=BAmain*BAN/BA
    if BA==0.: BAmainN=0.
  
    if OK_constant_CUE=='y':
    	CAEtmp=CAE*1.
    elif OK_constant_CUE=='n':
    	CAEtmp=CAE-K_CAE*(T-T_ref)
    	CAEtmp[CAEtmp<CAE_min]=CAE_min
    	CAEtmp[CAEtmp>CAE_max]=CAE_max
  
    ###C and N left then are used for enzyme systhesis
    C_for_enz=Uptake_adj-Rma
    if C_for_enz<0.: C_for_enz=0.
    N_for_enz=UptakeN_adj+BAmainN
  
    tmp1=(BCNopt/BACNtmp)**expc
    tmp2=(BACNtmp/BCNopt)**expc
    tmp=tmp1/(tmp1+tmp2)
    if tmp>vmax: tmp=vmax
    if tmp<vmin: tmp=vmin
    KeC=tmp*Ke
    KeN=(1.-tmp)*Ke
    
    EFC_factor1=KMFCE/(KMFCE+KMED)
    ESC_factor1=KMSCE/(KMSCE+KMED)
    if EFC_factor1<Ke_min: EFC_factor1=Ke_min
    if ESC_factor1<Ke_min: ESC_factor1=Ke_min
    if OK_N_ENZ=='y':
      EFN_factor1=KMFNE/(KMFNE+KMED)
      ESN_factor1=KMSNE/(KMSNE+KMED)
      if EFN_factor1<Ke_min: EFN_factor1=Ke_min
      if ESN_factor1<Ke_min: ESN_factor1=Ke_min
    
    EC_factor2=1.-s1
    EN_factor2=1.-s2
  
    if OK_check=='y':
      if np.isnan(EN_factor2):
         print 'Error: Nan in EN_factor2:',EN_factor2
         print 'saturation_level_N',saturation_level_N,'AvailN',AvailN,'KMAED',KMAED
         sys.exit()
    EFC_factor=(EFC_factor1*EC_factor2) # #Sinsabaugh et al., 2013
    ESC_factor=(ESC_factor1*EC_factor2) #
    if OK_N_ENZ=='y':
      EFN_factor=(EFN_factor1*EN_factor2) #
      ESN_factor=(ESN_factor1*EN_factor2) #
    
    if KMFCE+KMSCE==0.:
      tmp1=0.5
    else:
      tmp1=KMFCE**expc/(KMFCE**expc+KMSCE**expc)
    if tmp1>vmax: tmp1=vmax
    if tmp1<vmin: tmp1=vmin 
    KeCL=tmp1*EFC_factor
    KeCS=(1.-tmp1)*ESC_factor
    if OK_N=='y' and OK_N_ENZ=='y':
      if (KMFNE+KMSNE)==0.:
        tmp2=0.5
      else:
        tmp2=KMFNE**expc/(KMFNE**expc+KMSNE**expc)
      if tmp2>vmax: tmp2=vmax
      if tmp2<vmin: tmp2=vmin
      KeNL=tmp2*EFN_factor
      KeNS=(1.-tmp2)*ESN_factor
    else:
      KeNL=KeCL*0.
      KeNS=KeCS*0.
    
    if np.sum(np.isnan(KeNL)) and OK_check=='y' and OK_N_ENZ=='y' and OK_N=='y':
      print 'Error in KeNL: KeNL=',KeNL
      #print 'Er[:,0]=',Er[:,0]
      print  'tmp2=',tmp2
      print 'EFN_factor=',EFN_factor
      print 'EFN_factor1=',EFN_factor1    
      print 'EN_factor2=',EN_factor2
      print 'expc=',expc
      print 'KMFNE=',KMFNE,'KMSNE=',KMSNE
      sys.exit()
    
    #total amount of C and N need for enzyme production
    Cenz=BA*(KeCL*KeC+KeCS*KeC+KeNL*KeN+KeNS*KeN)
    Nenz=Cenz/ECN
  
    #only when production of enzymes is less than Ke_min fraction of supposed amount,microbes will use their own biomass to produce enzymes
    B_Cenz=Cenz/CAEtmp*Ke_min-C_for_enz
    B_Nenz=Nenz*Ke_min-N_for_enz
    if B_Cenz<0.: B_Cenz=0.
    if B_Nenz<0.: B_Nenz=0.
  
    ENZ_BCf=B_Cenz/(B_Cenz+C_for_enz)
  
    if  BA>0. and BAN>0.:
      if B_Cenz/BA>B_Nenz/BAN:
        fenz=B_Cenz/BA
        BAenz=B_Cenz
        BANenz=BAN*fenz
        BCresp=0.
        BNrelease=BANenz-B_Nenz
        ReL=BCresp*BALr+(BAenz-BCresp)*BALr*(1.-CAEtmp)
        #print 'HYcheck:1',BAenz,BAenz,BCresp,BNrelease,ReL
      else:
        fenz=B_Nenz/BAN
        BAenz=BA*fenz
        BANenz=B_Nenz
        BCresp=BAenz-B_Cenz
        BNrelease=0.
        ReL=BCresp*BALr+(BAenz-BCresp)*BALr*(1.-CAEtmp)
        #print 'HYcheck:2',BAenz,BAenz,BCresp,BNrelease,ReL
  
    tmp=BA-BAd-BAmain #-BAtoD
    if BAenz>tmp or BA<=0. or BAN<=0.: 
      BAenz=0.
      BANenz=0.
      BCresp=0.
      BNrelease=0.
      if Cenz>0.:
        ENZf=np.min([C_for_enz*CAEtmp,N_for_enz*ECN])/Cenz
      else:
        ENZf=1. #0 or 1, it does not matter
      ReL=Cenz*ENZf/CAEtmp*(1.-CAEtmp)*TUptake_adj_Lr #total respired C derived from FOM
      ENZ_BCf=0.
    else:
      ENZf=np.min([1.,np.min([(C_for_enz+B_Cenz)*CAEtmp,(N_for_enz+B_Nenz)*ECN])/Cenz]) #if the latter > 1, it means there more X than what is need for enzyme production and B_Xenz=0
      ReL=ReL+(Cenz*ENZf/CAEtmp-B_Cenz)*(1.-CAEtmp)*TUptake_adj_Lr #total respired C derived from FOM
  
    EFCg=KeCL*BA*KeC*ENZf
    ESCg=KeCS*BA*KeC*ENZf
    EFNg=KeNL*BA*KeN*ENZf
    ESNg=KeNS*BA*KeN*ENZf
    
    Re=(EFCg+ESCg+EFNg+ESNg)*(1.-CAEtmp)/CAEtmp+BCresp #total respiration during enzyme production
    ReN=BNrelease
    if Re<-zerol or ReN<-zerol:
      print 'Error: negative Re or ReN'
      print 'Re=',Re, 'ReN=',ReN
      print 'BAenz=',BAenz,'BANenz=',BANenz
      sys.exit()
    if Re<0.: Re=0.
    if ReN<0.: ReN=0.
    
    Cgrowth=C_for_enz-(EFCg+ESCg+EFNg+ESNg)/CAEtmp    #Cenz/CAEtmp #Uptake_adj-Rma
    if Cgrowth<=0.: Cgrowth=0.
    gC=Cgrowth*CAEtmp
  
    Ngrowth=N_for_enz+BANenz-(EFCg+ESCg+EFNg+ESNg)/ECN      #Nenz #UptakeN_adj
    if Ngrowth<0.: Ngrowth=0.
    gN=Ngrowth #/(BA/BCN[MFTtype])
    
    if gN>0.:
     if gC/gN>BCNmax: gC=gN*BCNmax
     if gC/gN<BCNmin: gN=gC/BCNmin
    else:
     gC=0.
  
    BAg=gC
    if OK_check=='y':
      if np.isnan(BAg):
        print 'Nan in BAg; BAg=',BAg
        print 'Cgrowth=',Cgrowth, 'Uptake_adj=',Uptake_adj,'Rma=',Rma
        print 'gN=',gN
        print 'BCNmax=',BCNmax
        sys.exit()
    Rg=gC*(1-CAEtmp)/CAEtmp	
    
    BANg=gN          
  
    if OK_N=='y':
        AvailNuptake_rlease=UptakeN_adj+BAmainN+BANenz-(EFCg+ESCg+EFNg+ESNg)/ECN-gN  #np.sum(Ngrowth-BAg/BCN[MFTtype],axis=0)
        if AvailNuptake_rlease<-zerol:
          print 'Error: negative AvailNuptake_rlease'
          print 'AvailNuptake_rlease=',AvailNuptake_rlease
          sys.exit()
        else:
          if AvailNuptake_rlease<0.: AvailNuptake_rlease=0. 
    elif OK_N=='n':
        AvailNuptake_rlease=0. #np.zeros((N))		
    
    if OK_Ro=='y':
      Ro=Cgrowth-BAg-Rg
      #Ro[Ro<=0.]=0.
      if Ro<=0.: Ro=0.
    else:
      Ro=0. #np.zeros((mn,N))
    respLM=(dLMC*(1-LMtoSS)+dGL)*(1-efLS)
    respLS=(dLSC*(1-LLfout)*(1.-LStoSS)+dLSC*LLfout*0.3)*(1-efLS)
    respSA=(dSAC*(1.-SAtoSS-SAtoSP))*(1-efSA)
    respSS=(dSSC*(1.-SStoSP))*(1-efSS)
    respSP=dSPC*(1-efSP)
    Rd=respLM+respLS+respSA+respSS+respSP
    RdL=respLM+respLS+respSA*SACLr+respSS*SSCLr+respSP*SPCLr
    
    sat=(BAg/(BAg+BAd+BAmain+BAenz))**2.
  
    c=0.5
    BAtmp=BA-BAd-BAmain-BAenz
    BAtoD=(1.-sat)*Km*BAtmp
    if BAtoD>BAtmp: BAtoD=BAtmp
    if BAtoD<0.:BAtoD=0.
  
    Rmd=BD*b*Km
    tmp=BD
    if Rmd>tmp: Rmd=tmp
    BDtmp=BD-Rmd
    BDtoA=sat*Km*BDtmp
    if BDtoA>BDtmp: BDtoA=BDtmp
    if BDtoA<0.:BDtoA=0.
  
    if OK_check=='y':
      if BAtoD<-zerol: #np.sum(BAtoD<-zerol):
        print 'Error: negative BAtoD'
        sys.exit()
      else:
        if BAtoD<0.: BAtoD=0.
    else:
      if BAtoD<0.: BAtoD=0.
  
    BAtoD_N=BAtoD*BAN/BA
    if BA==0.: BAtoD_N=0.
  
    BDtoA_N=BDtoA*BDN/BD
    if BD==0.: BDtoA_N=0.
  
    BDmain=Rmd
    Rm=Rma+Rmd
    
    BDmainN=BDmain*BDN/BD
    if BD==0.: BDmainN=0.           
  
    Tresp=Rm+Rg+Ro+Rd+Re
    MCUE1=(BAg+EFCg+ESCg+EFNg+ESNg)/(Tresp+BAg+EFCg+ESCg+EFNg+ESNg)
    if (Tresp+BAg)==0.: MCUE1=0.
  
    if (BAg+EFCg+ESCg+EFNg+ESNg+Rma+Rg+Rd+Re)>0:
      MCUE2=BAg/(BAg+EFCg+ESCg+EFNg+ESNg+Rma+Rg+Rd+Re)
    #if TUptake_adj>0.:
    #  MCUE2=BAg/TUptake_adj
    else:
      MCUE2=0.6
    if MCUE2<0.01: MCUE2=0.01
    if (BANg+(EFCg+ESCg+EFNg+ESNg)/ECN)>0:
      MNUE2=BANg/(BANg+(EFCg+ESCg+EFNg+ESNg)/ECN)
    #if TUptakeN_adj>0.:
    #  MNUE2=BANg/TUptakeN_adj
    else:
      MNUE2=1.
    if MNUE2<0.01: MNUE2=0.01
    if OK_check=='y':
      if np.isnan(MCUE2):
        print 'Nan in MCUE2: MCUE2=',MCUE2,'MCUE1=',MCUE1
        print 'BAg=',BAg,'Rma=',Rma,'Rg=',Rg,'BAg=',BAg
        sys.exit()
  
    RC=Tresp #Rg+Rm+Ro
    CAmain=BAmain
    NAmain=BAmainN
  
    RL=(Rg+Rma-CAmain+Ro)*TUptake_adj_Lr+Rmd*BDLr+CAmain*BALr+RdL+ReL #Re*BALr
    RS=RC-RL
    
    EaENZ=47.   #Ea_uptake*1. 41.5=Q10=1.79 #Purich, 2009 from He et al., 2015
    if OK_fixed_dENZ=='y':
        dENZ_adj=np.exp(-EaENZ/0.008314/T_exp)/np.exp(-EaENZ/0.008314/T_ref)
    else:
        dENZ_adj=np.exp(-EaENZ/0.008314/T)/np.exp(-EaENZ/0.008314/T_ref)
    EFCd=EFC*dENZ*dENZ_adj
    ESCd=ESC*dENZ*dENZ_adj
    EFNd=EFN*dENZ*dENZ_adj
    ESNd=ESN*dENZ*dENZ_adj
    
    tmp=EFC #+EFCg
    if EFCd>tmp: EFCd=tmp
    tmp=ESC #+ESCg
    if ESCd>tmp: ESCd=tmp
    tmp=EFN #+EFNg
    if EFNd>tmp: EFNd=tmp
    tmp=ESN #+ESNg
    if ESNd>tmp: ESNd=tmp
  
    if OK_control=='y':
      if BA<MFT_min:
        EFCd=0.; EFNd=0.;ESCd=0.;ESNd=0.
    
    EFCout=EFC+EFCg-EFCd
    EFNout=EFN+EFNg-EFNd
    #ELPout=ELP+ELPg-ELPd
    ESCout=ESC+ESCg-ESCd
    ESNout=ESN+ESNg-ESNd
    #ESPout=ESP+ESPg-ESPd
  
    if ESNout<0:
      print 'ESNout','ESN',ESN,'ESNg',ESNg,'ESNd',ESNd
      print 'Negative ESNout, stop'
      sys.exit()
    if OK_check=='y':
      if np.sum(EFCout<0.) or np.sum(ESCout<0.):
        print 'Warning: EFCout or ESCout is negative'
        print 'EFCout',EFCout
        print 'ESCout',ELSout
        sys.exit()
    if EFCout<-zerol or ESCout<-zerol or EFNout<-zerol or ESNout<-zerol:
      print 'EFCout',EFCout,'ESCout',ESCout,'EFNout',EFNout,'ESNout',ESNout
      print 'Error in ENZ'
      sys.exit()
  
    if EFCout<0.: EFCout=0.          
    if ESCout<0.: ESCout=0.
    if EFNout<0.: EFNout=0.
    if ESNout<0.: ESNout=0.
  
    if EFCout>0.:
      EFCLrout=(EFC*EFCLr+EFCg*(1.-ENZ_BCf)*TUptake_adj_Lr+EFCg*ENZ_BCf*BALr-EFCd*EFCLr)/EFCout
    else:
      EFCLrout=0.
    if EFNout>0.:
      EFNLrout=(EFN*EFNLr+EFNg*(1.-ENZ_BCf)*TUptake_adj_Lr+EFNg*ENZ_BCf*BALr-EFNd*EFNLr)/EFNout
    else:
      EFNLrout=0.
    if ESCout>0.:
      ESCLrout=(ESC*ESCLr+ESCg*(1.-ENZ_BCf)*TUptake_adj_Lr+ESCg*ENZ_BCf*BALr-ESCd*ESCLr)/ESCout
    else:
      ESCLrout=0.
    if ESNout>0.:
      ESNLrout=(ESN*ESNLr+ESNg*(1.-ENZ_BCf)*TUptake_adj_Lr+ESNg*ENZ_BCf*BALr-ESNd*ESNLr)/ESNout
    else:
      ESNLrout=0.
    EFCSrout=1.-EFCLrout
    EFNSrout=1.-EFNLrout
    #ELPSrout=1.-ELPLrout
    ESCSrout=1.-ESCLrout
    ESNSrout=1.-ESNLrout
    #ESPSrout=1.-ESPLrout
    
    BAout=BA+BAg-BAmain-BAenz-BAd-BAtoD+BDtoA
    BDout=BD-BDmain+BAtoD-BDtoA
  
    BANout=BAN+BANg-BAmainN-BANenz-BANd-BAtoD_N+BDtoA_N
    BDNout=BDN-BDmainN+BAtoD_N-BDtoA_N
    if BANout<-zerol or BDNout<-zerol:
      print 'Error in BAN or BDN'
      print 'BANout',BANout,'BDNout',BDNout
      print 'BAN',BAN,'BANg',BANg,'BAmainN',BAmainN,'BANenz',BANenz,'BANd',BANd,'BAtoD_N',BAtoD_N,'BDtoA_N',BDtoA_N
      sys.exit()
    if BANout<0.: BANout=0.
    if BDNout<0.: BDNout=0.		
  
    if OK_check=='y' and np.isnan(BANout):
     print 'BAN',BAN,'BANg',BANg,'BAmainN',BAmainN,'BANenz',BANenz,'BANd',BANd,'BAtoD_N',BAtoD_N,'BDtoA_N',BDtoA_N
     sys.exit()
  
    if np.sum(np.isnan(BAout)) and OK_check=='y':
      print 'BAout=',BAout
      print 'BA=',BA
      print 'BAg=',BAg
      print 'BAmain=',BAmain
      print 'BAenz=',BAenz
      print 'BAd=',BAd
      print 'BAtoD=',BAtoD
      print 'BDtoA=',BDtoA
    
    BALrout=(BA*BALr+BAg*TUptake_adj_Lr-BAmain*BALr-BAenz*BALr-BAd*BALr-BAtoD*BALr+BDtoA*BDLr)/BAout
    if BAout<=0.: BALrout=0.
    if BALrout<0.: BALrout=0.
    if BALrout>1.: BALrout=1.
    BASrout=1.- BALrout
    
    BDLrout=(BD*BDLr-BDmain*BDLr+BAtoD*BALr-BDtoA*BDLr)/BDout
    if BDout<=0.: BDLrout=0.
    if BDLrout<0.: BDLrout=0.
    if BDLrout>1.: BDLrout=1.
    BDSrout=1.- BDLrout
    
    if OK_check=='y':
      if np.sum(BAout<-zerol) or np.sum(BDout<-zerol):
        print 'Warning: BAout or BDout is negative'
        #print 'BAout[BAout<0.]',BAout[BAout<0.]
        #print 'BDout[BDout<0.]',BDout[BDout<0.]
        sys.exit()
      else:
        #BAout[BAout<0.]=0.
        #BDout[BDout<0.]=0.
        if BAout<0.: BAout=0.
        if BDout<0.: BDout=0.
      if np.sum(BALrout<0.):
        print 'Error: Negative BALrout'
        #print 'BAout[BALrout<0.]',BAout[BALrout<0.]
        #print '(BA*BALr+BAg*AvailCLr-BAmain*BALr-BAenz*BALr-BAd*BALr-BAtoD*BALr+BDtoA*BDLr)[BALrout<0.]',(BA*BALr+BAg*AvailCLr-BAmain*BALr-BAenz*BALr-BAd*BALr-BAtoD*BALr+BDtoA*BDLr)[BALrout<0.]
        sys.exit()
    else:
      #BAout[BAout<0.]=0.
      #BDout[BDout<0.]=0.
      if BAout<0.: BAout=0.
      if BDout<0.: BDout=0.
  
    
    #update Avail pool
    AvailC2_tmp=AvailC_tmp+AvailCdec-TUptake_adj
    AvailC2Lr_tmp=(AvailC_tmp*AvailCLr_tmp+AvailCdec*AvailCdecLr-TUptake_adj*TUptake_adj_Lr)/AvailC2_tmp
    #AvailC2Lr_tmp[AvailC2_tmp==0.]=0
    if AvailC2_tmp==0.: AvailC2Lr_tmp=0.
    if np.sum(np.isnan(AvailC2_tmp)):
        print 'Error in lin 993 for AvailC2_tmp'
        print 'AvailC_tmp',AvailC_tmp
        print 'AvailCLr_tmp',AvailCLr_tmp
        print 'AvailCdec',AvailCdec
        print 'AvailCdecLr',AvailCdecLr
        print 'TUptake_adj',TUptake_adj
        print 'TUptake_adj_Lr',TUptake_adj_Lr
        print 'AvailC2_tmp',AvailC2_tmp
        sys.exit()
    
    AvailCmob=KdesC*StabC/StabCmax
    #AvailCmob[AvailCmob>StabC]=StabC[AvailCmob>StabC]
    if AvailCmob>StabC: AvailCmob=StabC          
    if AvailCmob<0:
      print 'Error: negative AvailCmob'
      print 'KdesC',KdesC,'StabC',StabC,'StabCmax',StabCmax
      sys.exit()
  
    if OK_absorb_N=='y':
      AvailNmob=KdesC*StabN/StabCmax  #AvailCmob*StabN/StabC
    else:
      AvailNmob=AvailCmob*0.
    
    AvailCstab=AvailC*KabsC*(1-np.min([1.,StabC/StabCmax]))
    #AvailCstab[AvailCstab<0.]=0.
    if AvailCstab<0.: AvailCstab=0.
    tmp=AvailC2_tmp #-TUptake_adj
    #AvailCstab[AvailCstab>tmp]=tmp[AvailCstab>tmp]
    if AvailCstab>tmp: AvailCstab=tmp         
    #print 'HYcheck for AvailNstab:','AvailN',AvailN,'KabsC',KabsC,'StabN',StabN,'StabCmax',StabCmax
    if OK_absorb_N=='y':
      AvailNstab=AvailN*KabsC*(1.-np.min([1.,StabN/StabCmax]))  #AvailCstab*AvailN/AvailC
      tmp=AvailN_tmp-TUptakeN_adj
      #AvailNstab[AvailNstab>tmp]=tmp[AvailNstab>tmp]
      if AvailNstab>tmp: AvailNstab=tmp
    else:
      AvailNstab=AvailCstab*0.
    
    AvailCloss=AvailC*KlossC
    tmp=AvailC2_tmp-AvailCstab
    #AvailCloss[AvailCloss>tmp]=tmp[AvailCloss>tmp]
    if AvailCloss>tmp: AvailCloss=tmp          
  
    AvailCout=AvailC2_tmp-AvailCloss-AvailCstab+AvailCmob
    if AvailCout>0.:
      AvailCLrout=(AvailC2_tmp*AvailC2Lr_tmp-AvailCloss*AvailC2Lr_tmp-AvailCstab*AvailC2Lr_tmp+AvailCmob*StabCLr)/AvailCout
    else:
      AvailCLrout=0.
    AvailCSrout=1.-AvailCLrout
    
    AvailNmain=BDmainN
    
    if AvailCout<-zerol:
      print 'Negative AvailCout: AvailCout=',AvailCout
      print 'AvailC2_tmp',AvailC2_tmp,'AvailCloss',AvailCloss,'AvailCstab',AvailCstab,'AvailCmob',AvailCmob
      sys.exit()
    else:
      if AvailCout<0.: AvailCout=0.
  
    AvailNloss2=AvailN*KlossN #leach
    AvailNtmp=AvailN_tmp-TUptakeN_adj-AvailNstab+AvailNmob+AvailNmain+AvailNuptake_rlease #+ReN
    if AvailNloss2>AvailNtmp: AvailNloss2=AvailNtmp
    AvailNloss=(NdecLM+NdecLS+NdecSA+NdecSS+NdecSP)*KlossN2+AvailNloss2  #Same as Parton et al., 1987, %5 of totoal mineralization flux as volatilization and leach was negelected
    AvailNout=AvailN_tmp-TUptakeN_adj-AvailNstab+AvailNmob+AvailNmain+AvailNuptake_rlease-AvailNloss2 #+ReN #Here is different from that for C, because AvailN_tmp has alreay considered AvailNloss
    if AvailNout<-zerol:
      print 'Negative AvailNout: AvailNout=',AvailNout
      sys.exit()
    else:
      if AvailNout<0.: AvailNout=0.
    
  
    tmp=AvailNout*1.
    VegNuptakep=tmp*Nuptakef
    if VegNuptakep>Nplant: 
      VegNuptakep=Nplant
    if OK_plant_uptake_N=='y':
      AvailNout=AvailNout-VegNuptakep
      plantNuptake=VegNuptakep
    else:
      plantNuptake=0.
  
    #update three Litter C pools
    GLout=GL-dGL #+GLin
    LMCout=LMC-dLMC+LMCin
    LSCout=LSC-dLSC+LSCin
    
    LMNout=LMN-dLMN+LMNin
    LSNout=LSN-dLSN+LSNin
    
    if OK_check=='y':
      if LMCout<=-zerol:
        print 'Error: negative LMCout'
        sys.exit()
      if LSCout<=-zerol:
        print 'Error: negative LMCout'
        sys.exit()
      if LMNout<=-zerol:
        print 'Error: negative LMCout'
        sys.exit()
      if LSNout<=-zerol:
        print 'Error: negative LMCout'
        sys.exit()
    if LMCout<0.: LMCout=0.
    if LSCout<0.: LSCout=0.
    if LMNout<0.: LMNout=0.
    if LSNout<0.: LSNout=0.
    
    #update SAC pool
    SACmicd=BAd*(1.-sC)
    SANmicd=BANd*(1.-sN)          
    SACmicdL=BAd*BALr*(1.-sC)
  
    SACenzd=EFCd+ESCd+EFNd+ESNd
    SANenzd=(EFCd+ESCd+EFNd+ESNd)/ECN
    SACenzdL=(EFCd*EFCLr+ESCd*ESCLr+EFNd*EFNLr+ESNd*ESNLr)
  
    SACout=SAC+SACmicd+SACenzd-dSAC
    if SACout<0.: SACout=0.
    SANout=SAN+SANmicd+SANenzd-dSAN
    if SANout<0.: SANout=0.
    SACLrout=(SAC*SACLr+SACmicdL+SACenzdL-dSAC*SACLr)/SACout
    if SACout<=0.: SACLrout=0.
    SACSrout=1.-SACLrout
    
    
    #update SSC pool
    SSCout=SSC+dLMC*LMtoSS+(dLSC*(1-LLfout)*LStoSS+dLSC*LLfout*(1-0.3))+dSAC*SAtoSS-dSSC
    #SSCout[SSCout<0.]=0
    if SSCout<0.: SSCout=0.
    SSNout=SSN+dLMN*LMtoSS+(dLSN*(1-LLfout)*LStoSS+dLSN*LLfout*(1-0.3))+dSAN*SAtoSS-dSSN
    if SSNout<0.: SSNout=0.
    SSCLrout=(SSC*SSCLr+dLMC*LMtoSS+(dLSC*(1-LLfout)*LStoSS+dLSC*LLfout*(1-0.3))+dSAC*SAtoSS*SACLr-dSSC*SSCLr)/SSCout
    #SSCLrout[SSCout<=0.]=0.
    if SSCout<=0.: SSCLrout=0.
    SSCSrout=1.-SSCLrout
    
    
    #update SPC pool
    SPCout=SPC+dSAC*SAtoSP+dSSC*SStoSP-dSPC
    SPNout=SPN+dSAN*SAtoSP+dSSN*SStoSP-dSPN		
    
    SPCLrout=(SPC*SPCLr+dSAC*SAtoSP*SACLr+dSSC*SStoSP*SSCLr-dSPC*SPCLr)/SPCout
    #SPCLrout[SPCout<=0.]=0.
    if SPCout<=0.: SPCLrout=0.
    SPCSrout=1.-SPCLrout
    
    StabCout=StabC+AvailCstab-AvailCmob
    StabNout=StabN+AvailNstab-AvailNmob
    #StabNout[StabNout<0.]=0.
    if StabNout<0.: StabNout=0.          
  
    StabCLrout=(StabC*StabCLr+AvailCstab*AvailC2Lr_tmp-AvailCmob*StabCLr)/StabCout
    #StabCLrout[StabCout<=0.]=0.
    if StabCout<=0.: StabCLrout=0.
    StabCSrout=1.-StabCLrout #(StabC*StabCSr+StabCabs*AvailCSr-StabCdes*StabCSr)/StabCout
    
    if OK_check=='y':
      if np.sum(StabCout<-zerol):
        print 'Error: negative StabCout'
        #print 'StabCout[StabCout<-zerol]',StabCout[StabCout<-zerol]
        sys.exit()
    if StabCout<0.: StabCout=0.          
  
    if OK_check=='y':
        #check mass balance for C
    	C1=AvailCin+LMCin+LSCin+GL+LMC+LSC+SAC+SSC+SPC+AvailC+StabC+BA+BD+EFC+ESC+EFN+ESN #np.sum((BA+BD+EFC+ESC+EFN+ESN),axis=0)
    	C2=GLout+LMCout+LSCout+SACout+SSCout+SPCout+AvailCout+StabCout+BAout+BDout+EFCout+ESCout+EFNout+ESNout+Rma+Rmd+Rg+Ro+Re+Rd+AvailCloss
    	print 'C=',C1,C2
    	if np.sum(np.abs(C1-C2)>1e-5):
    	  print 'Error: C mass is not close'
    	  #print 'np.sum(np.abs(C1-C2)>1e-5)',np.sum(np.abs(C1-C2)>1e-5)
    	  #print '(C1-C2)[np.abs(C1-C2)>1e-5]',(C1-C2)[np.abs(C1-C2)>1e-5]
    	  #print 'C1[np.abs(C1-C2)>1e-5]',C1[np.abs(C1-C2)>1e-5]
    	  #print 'C2[np.abs(C1-C2)>1e-5]',C2[np.abs(C1-C2)>1e-5]
          print AvailCin,LCin,GL,LMC,LSC,SAC,SSC,SPC,SPC,SPC,BA,BD,EFC,ESC,EFN,ESN
          print GLout,LMCout,LSCout,SACout,SSCout,SPCout,AvailCout,StabCout,np.sum((BAout+BDout+EFCout+ESCout+EFNout+ESNout),axis=0),np.sum(Rma+Rmd+Rg+Ro,axis=0),AvailCloss
    	  print BAout,BDout,EFCout,ESCout,EFNout,ESNout,Rma,Rmd,Rg,Ro
          sys.exit()
    
        if OK_N=='y':
            #check mass balance for N
    	    N1=LMNin+LSNin+AvailNin+LMN+LSN+SAN+SSN+SPN+AvailN+StabN+BAN+BDN+(EFC+ESC+EFN+ESN)/ECN #np.sum((BA+BD)/BCN[MFTtype],axis=0)+np.sum((EFC+ESC+EFN+ESN)/ECN[MFTtype],axis=0)
            N2=LMNout+LSNout+SANout+SSNout+SPNout+AvailNout+StabNout+BANout+BDNout+(EFCout+ESCout+EFNout+ESNout)/ECN+AvailNloss+plantNuptake #np.sum((BAout+BDout)/BCN[MFTtype],axis=0)+np.sum((EFCout+ESCout+EFNout+ESNout)/ECN[MFTtype],axis=0)+AvailNloss+AvailNloss2+plantNuptake
            print 'N=',N1,N2
            if np.sum(np.abs(N1-N2)>1e-6):
              print 'Error: N mass is not close'
              #print 'np.sum(np.abs(N1-N22)>1e-6)',np.sum(np.abs(N1-N2)>1e-6)
              #print '(N1-N2)[np.abs(N1-N2)>1e-6]',(N1-N2)[np.abs(N1-N2)>1e-6]
              #print '(C1-C2)[np.abs(N1-N2)>1e-6]',(C1-C2)[np.abs(N1-N2)>1e-6]
    	      #print 'N1[np.abs(N1-N2)>1e-6]',N1[np.abs(N1-N2)>1e-6]
              #print 'N2[np.abs(N1-N2)>1e-6]',N2[np.abs(N1-N2)>1e-6]
              sys.exit()
    
        #check mass balance for FOM-derived C
        CF1=AvailCin+np.sum(LCin)+GL+LMC+LSC+SAC*SACLr+SSC*SSCLr+SPC*SPCLr+AvailC*AvailCLr+StabC*StabCLr+BA*BALr+BD*BDLr+EFC*EFCLr+ESC*ESCLr+EFN*EFNLr+ESN*ESNLr
        CF2=GLout+LMCout+LSCout+SACout*SACLrout+SSCout*SSCLrout+SPCout*SPCLrout+AvailCout*AvailCLrout+StabCout*StabCLrout+BAout*BALrout+BDout*BDLrout+EFCout*EFCLrout+ESCout*ESCLrout+EFNout*EFNLrout+ESNout*ESNLrout+RL+AvailCloss*AvailC2Lr_tmp
    	print 'CF',CF1,CF2
        if np.sum(abs(CF1-CF2)>1e-6):
                print 'Error: CF is not closed'
                print 'CF1',CF1
                print 'CF2',CF2
                print 'C',C1,C2
                print AvailCin
                print LCin
                print GL
                print LMC
                print LSC
                print SAC*SACLr
                print SSC*SSCLr
                print SPC*SPCLr
                print AvailC*AvailCLr
                print StabC*StabCLr
                #print np.sum((BA*BALr+BD*BDLr+EFC*EFCLr+ESC*ESCLr),axis=0)
                sys.exit()
    
    if OK_control=='y':
      if BAout<MFT_min: 
        BAout=MFT_min
      if BANout<MFT_min/BCNmax:
        BANout=BAout/BCNmax
    
    return GLout,LMCout,LMNout,LSCout,LSNout,LLfout,SACout,SANout,SSCout,SSNout,SPCout,SPNout,AvailCout,AvailNout,BAout,BANout,BDout,BDNout,EFCout,ESCout,EFNout,ESNout,EFCeq,ESCeq,StabCout,StabNout,MCUE1,MCUE2,MNUE2,saturation_level,Rd,Ro,Rg,Rm,RC,gC,gN,AvailCLrout,AvailCSrout,StabCLrout,StabCSrout,SACLrout,SACSrout,SSCLrout,SSCSrout,SPCLrout,SPCSrout,BALrout,BASrout,BDLrout,BDSrout,EFCLrout,EFCSrout,ESCLrout,ESCSrout,EFNLrout,EFNSrout,ESNLrout,ESNSrout,dGL,dLMC,dLMN,dLSC,dLSN,dSAC,dSAN,dSSC,dSSN,dSPC,dSPN,BAg,BANg,BAd,Rma,Rmd,RL,RS,AvailCstab,AvailNstab,AvailCmob,AvailNmob,AvailCloss,AvailNloss,EFCg,ESCg,EFNg,ESNg,plantNuptake
  
  
  ##########################################################
  ################### Paramters set ########################
  ##########################################################			
  #all are molar ratio
  BCN=np.zeros((4,1))
  BCN[:,0]=np.array([6.12,4.59,8.3,6.12]) #Mouginot et al., 2014
  #values used here are all from Xu et al., 2013 for different biomes
  BCNmin=4.5
  BCNmax=12.5
  BCNopt=7.6
  #ECN=BCN
  ECN=3. #Sterner and Elser, 2002 in Allison et al., 2014
  
  sC=0.06 #0.06 from C. Kaiser et al. 2014 and 2015
  sN=0.06
  sP=0.06
  
  print 'Peform one-point simulaiton for global test'
  ###########################################################
  #flags
  #read paramter values from variables xt?
  OK_read_xt='n'
  #consider N uptake by vegetation
  OK_plant_uptake_N='y'
  #consider N deposition
  OK_Ndep='y'
  #consider C and N leaching
  OK_loss='y'
  #consider overflow respiraiton
  OK_Ro='y'
  #consider adsorption of C
  OK_stab_C='y'
  #set minimum microbial biomass 
  OK_control='y'
  #restart simulation?
  OK_restart='n'
  #reset FOM-derived C fraction in each pool?
  OK_reset_Lr='n'
  
  ############################################################
  #read input data#
  indir0='/ccc/cont003/home/lsce/huangy/microbe/data/input/'
  landpointdir=indir0+'LCin/5deg/'
  landpoint=np.load(landpointdir+'landpoint.npy')
  #load input data
  indir1=indir0+'LCin5deg/LCin/'
  indir2=indir0+'LCin/LCN5deg/'
  indir3=indir0+'LCin/soil_info/5deg/'
  indir4=indir0+'LCin/dep5deg/'
  indir5=indir0+'LCin5deg/npp/'
  indir6=indir0+'MT/5deg/'
  
  vegmax=np.load(indir1+'vegmax.npy')
  leafin=np.load(indir1+'leafin.npy')
  rootin=np.load(indir1+'rootin.npy')
  woodin=np.load(indir1+'woodin.npy')
  lmaskLC=np.load(indir1+'lmask.npy')
  lmaskLC[np.isnan(np.ma.mean(leafin,axis=0))]=1
  lmaskLC[np.isnan(np.ma.mean(rootin,axis=0))]=1
  leafin=np.ma.masked_array(leafin,np.isnan(leafin))
  rootin=np.ma.masked_array(rootin,np.isnan(rootin))
  woodin=np.ma.masked_array(woodin,np.isnan(woodin))
  #woodin=woodin*0.
  #sys.exit()
  
  npp_factor=np.load(indir5+'npp_factor.npy')
  if np.sum(npp_factor)>1.00001 or np.sum(npp_factor)<(1.-0.00001):
     print 'Erorr in npp_factor'
     sys.exit()
  
  Hsoilin=np.load(indir6+'SM.npy')
  Tsoilin=np.load(indir6+'ST.npy')
  
  leafCNin=np.load(indir2+'leafCN5deg.npy') #gC/m2/day
  rootCNin=np.load(indir2+'rootCN5deg.npy')
  woodCNin=np.load(indir2+'woodCN5deg.npy')
  lmaskLCNin=np.load(indir2+'mask.npy')
  woodCNin[woodCNin==0]=np.nan
  SBDin=np.load(indir3+'BD.npy') #kg soil/m3
  CCin=np.load(indir3+'CC.npy') #percetage, divide by 100 to get the fraction
  CCin=CCin/100.
  lmaskBD=np.load(indir3+'BDmask.npy')
  lmaskCC=np.load(indir3+'CCmask.npy')
  
  Ndep1=np.load(indir4+'ndep_1850_5deg.npy') #mgN/m2/yr
  Ndep2=np.load(indir4+'ndep_1960_5deg.npy')
  if OK_Ndep=='y':
    Ndeps=0.5*(Ndep1+Ndep1)/365./24.*1e-3  #gN/m2/h
  else:
    Ndeps=0.0*(Ndep1+Ndep2)/365./24.*1e-3
  
  #load parameter values
  if OK_read_xt=='y':
      #path of xt variables
      indir='path'
      xt=np.load(indir+'xt.npy')
      xx=xt*1.
      xxnv=np.size(xx)
  
  #some values that need to default, but may not used
  pH=7.
  Actf=0.05
  Pasf=0.5
  
  #Default values for parameters
  Adj_GL          =1000.  #not used
  Adj_LS          =3.7 #5.02/0.96  # ratio of decomposition rate of metabolic litter to that of structure litter
  Adj_SA          =37. #ratio of decompostion rate of active pool to that of slow pool
  Adj_SP          =29. #ratio of decomposition rate of slow pool to that of passive pool
  AvailCrin       =0.098/24. #0.002 #0.005773157  #ratio of available C to SOC, not important parameter
  b               =0.001 #ratio of maintenance respiration coefficient of dormant to Km (Kr in paper)
  BArin           =0.2 #+np.zeros((N)) #active biomass fraction
  CAE             =0.6 #maximum carbon use efficiency
  dENZ            =0.001 #turn over rate of enzymes
  dMFTref         =0.02 #0.001/0.249/0.2 #deat rate of active microbes, noted that non-linear death rate was applied in this version
  Ea_main         =60. #60. #Tang and Riley, 2015 #20.     #see Wang et al., 2013, activation energy for maintenance respiration
  EaGL            =28.9    #Odebunmi and Owalude, 2007 #not used
  EaKM            =30.     #Davidson et al. (2006) from Wang et al., 2013 #activation energy for Michaelis-Menton constants
  EaLM            =37.     #Wang et al., 2012b from Wang et al., 2013  #activation energy for metabolic litter decomposition
  EaLS            =53.     #Wang et al., 2012b from Wang et al., 2013 #activation energy for structural litter decomposition
  Ea_mob	  =20.     ##Check references cited by Wang et al., 2013 #activation energy for desorption
  EaSA            =47.     ##activation energy for active pool decompostion
  EaSP            =135.5   #70 for a tannin compound from Davidson and Janssens, 2006; 135.5 from Leifeld and Lutzow,2014,#activation energy for slow pool decompostion
  EaSS            =135.5   #70.     #70 #53.     #47. Allison et al., 2010  ##activation energy for passive pool decompostion
  Ea_stab	  =5.      #Check references cited by Wang et al., 2013  ##activation energy for adsorption
  Ea_uptake       =47.     #47 from Allison et al., 2010 #activation energy for microbial uptake
  expc            =1.      #expc   #parameter
  efLS            =1. #+np.zeros((N))  #not used
  efSA            =1. #+np.zeros((N))  #not used
  efSP            =1. #+np.zeros((N))  #not used
  efSS            =1. #+np.zeros((N))  #not used
  ELrin           =np.array([0.00,0.25,0.75,0.50]) #not used
  FErin		  =0.1 #not used
  #H0              =H       #0.6 #not used
  Hs              =0.4      #not used
  KBAC            =10.#/1000.*12.    #6(1-11) g soil/mg C Wang et al., 2013; 10  Wang et al., 2015  #soil bind affinity
  K_CAE           =0.012 #Devevre and Horwath 2000 from Wang et al., 2013 #CAE senstivity paramer to temeprature ,not used
  KdesC           =0.001 #+np.zeros(N)   #Wang et al., 2013 ##desorption rate
  Kdin            =0.  #not used
  Kein            =1.e-4 #0.0002  #enzyme production coefficient
  Ke_min          =0.1 #+np.zeros((N))  #not used 
  KlossC          =0.05/365./24. #+np.zeros((N)) #leaching rate
  KlossN          =0.05/365./24. #+np.zeros((N)) #leaching rate
  KlossN2         =0.05 #+np.zeros((N)) #KlossN is totally different from KlossC, as in Parton et al., 1987, %5 of totoal mineralization flux as volatilization
  KMAED           =0.005   #paramter, not used
  #KME_FOM         =50.
  #KME_SOM         =250.
  Km_ref          =0.002 #reference maintenance respiration rate
  KMLC            =50.   #Machaelis-Menton constant for litter (or FOM) decomposition 
  KMSC            =250.  #Machaelis-Menton constant for SOM decomposition 
  KM_uptake       =0.1   #Machaelis-Menton constant for microbial uptake
  LMtoSS          =0.2 #+np.zeros((N))  # fraction of LM (metabolic litter) will go to Slow pool
  LStoSS          =0.2 #+np.zeros((N))  # fraction of LS (stuctural litter) will go to Slow pool
  pH0             =pH  #pH, not used
  pH0_dec         =pH      #5. #not used
  pHs		  =2.   #not used
  pHs_dec         =2.   #not used
  SACrin	  =Actf  #temperal variable
  SErin		  =0.5  #temperal variable
  SPCrin	  =Pasf  #temperal variable
  StabCmax	  =1.35 #*1000/12. #mmol C/kg soil from 1.7 mg C/g soil from Mayes et al. (2012) in wang et al., 2013   #soil adsorption capacity
  #T0              =T 
  Ts		  =15. #not used
  VmaxLMC         =81.*Adj_LS #decompostion rate of metabolic litter
  VmaxSSC         =2.5   #decomposition rate of slow pool
  VmaxUptake_refin=0.24 #0.24/0.2  #microbial uptake rate 
  KCN		  =1. #not used
  
  
  SStoSP          =0.03 #x[25]  #fraction of SS (slow pool) to SP (passive pool)
  SAtoSP          =0.004   #fraction of SA (active pool) to SP (passive pool)
  KMED            =1  #parameter
  Nuptakef        =0.05 #0.05 for v24.1 and 0.1 for v24 #maximum allowed fraction of avaiable N can be taken up by plants and leaching
  expuptake       =1.  #parameter
  T_ref           =273.15+12.  #reference temperature
  
  T_exp=T_ref  #
  
  
  if OK_read_xt=='y':
    #make sure parameter values are read in right sequence
    #Read values from outside of function for parameters           
    ll=-1
    #ll=ll+1; Adj_GL          =xx[ll]
    #ll=ll+1; Adj_LS          =xx[ll]
    #ll=ll+1; Adj_SA          =xx[ll]
    #ll=ll+1; Adj_SP          =xx[ll]
    #ll=ll+1; AvailCrin       =xx[ll]
    ll=ll+1; b               =10**(xx[ll])
    ll=ll+1; BArin           =xx[ll]
    #ll=ll+1; CAE             =xx[ll]
    #ll=ll+1; dENZ            =10**(xx[ll])
    ll=ll+1; dMFTref         =10**(xx[ll])
    #ll=ll+1; Ea_main         =xx[ll]
    #ll=ll+1; EaGL            =xx[ll]
    #ll=ll+1; EaLM            =xx[ll]
    #ll=ll+1; EaLS            =xx[ll]
    #ll=ll+1; EaSA            =xx[ll]
    #ll=ll+1; EaSP            =xx[ll]
    #ll=ll+1; EaSS            =xx[ll]
    #ll=ll+1; Ea_uptake       =xx[ll]
    ll=ll+1; expc           =10**xx[ll]
    #ll=ll+1; efLS           =xx[ll]
    #ll=ll+1; efSA           =xx[ll]
    #ll=ll+1; efSP           =xx[ll]
    #ll=ll+1; efSS           =xx[ll]
    ll=ll+1; FECrin		=10**(xx[ll])
    ll=ll+1; FENrin          =10**(xx[ll])
    #ll=ll+1; H0              =xx[ll]
    #ll=ll+1; Hs              =xx[ll]
    #ll=ll+1;KabsC		=xx[ll]
    ll=ll+1; KBAC            =xx[ll]
    #ll=ll+1; K_CAE           =xx[ll]
    #ll=ll+1; Kdin           =xx[ll]
    ll=ll+1; KdesC           =10**(xx[ll])
    ll=ll+1; Kein            =10**(xx[ll])
    #ll=ll+1; Ke_min          =xx[ll]
    #ll=ll+1; KlossC          =xx[ll]
    ll=ll+1; KMAED       =10**(xx[ll])
    #ll=ll+1; KME_FOM        =xx[ll]
    #ll=ll+1; KME_SOM        =xx[ll]
    ll=ll+1; Km_ref          =10**(xx[ll])
    ll=ll+1; KMLC            =10**(xx[ll])
    ll=ll+1; KMSC            =10**(xx[ll])
    ll=ll+1; KM_uptake       =10**(xx[ll])
    ll=ll+1; LStoSS          =10**xx[ll]
    #ll=ll+1; pH0_dec         =xx[ll]
    #ll=ll+1; pHs_dec         =xx[ll]
    #ll=ll+1; SACrin		=xx[ll]
    ll=ll+1; SECrin           =(xx[ll])
    ll=ll+1; SENrin           =10**(xx[ll])
    #ll=ll+1; SPCrin		 =xx[ll]
    ll=ll+1; StabCmax	 =10**(xx[ll])
    #ll=ll+1; T0              =xx[ll]
    #ll=ll+1; Ts              =xx[ll]
    ll=ll+1; VmaxLMC         =10**(xx[ll])
    ll=ll+1; VmaxSSC         =10**(xx[ll])
    ll=ll+1; VmaxUptake_refin=xx[ll]
    #ll=ll+1; KCN		=xx[ll]
    ll=ll+1; KMED            =10**(xx[ll])
    ll=ll+1; expuptake       =10**(xx[ll])
    #ll=ll+1; BCNopt          =xx[ll]
    
    if not (ll+1)==xxnv:
      print 'Error: read values for parameters'
      print 'll+1=',ll+1, '  xxnv=',xxnv
      sys.exit()
  
  KabsC=KdesC*KBAC
  
  mn=1 #not used any more
  MFTtype=[3] #not used any more
  gridid_start=start_gridid
  for gid in np.arange(gridid_start,gridid_start+N_gridid,1):
      print 'Now start simulation for gridid=',gid
      latn=int(landpoint[gid,0])
      lonn=int(landpoint[gid,1])
      print 'Current at: latn',latn,'lonn',lonn
      exp=str(gid)
      if OK_test=='y':
              outdir=outdir0+'glotranp/test/'
      else:
              outdir=outdir0+'glotranp/'+vers+'/'+exp+'/'
  
      if not os.path.exists(outdir):
              os.makedirs(outdir)
  
      if OK_restart=='y':
          #restart_dir='/home/surface3/yhuang/microbe/glotranp/CN_v21_m1_ECN_AbsCN/cost1/0/'+str(gid)+'/99/'
          restart_dir='/home/surface4/yhuang/microbe/glotranp/CN_v38_m1_ECN_AbsCN/cost1/0/0/196/'
      
      ##not used, but is kept as input to the defined function
      #if MFT==1:
      #        gidn=0
      #        mn=1
      #        MFTtype=[3]
      #else:
      #  print 'The number of MFTs set is wrong, the model does not support with more than 1 MFT any more'
      #  sys.exit()
  
      print 'outdir=',outdir
      np.save(outdir+'latn.npy',latn)
      np.save(outdir+'lonn.npy',lonn)
  
  
      #Initialize pools
      TC=10.
      LC0=1.
      SCN=12.
  
  
      AvailC0=TC*0.005 #+np.zeros((1,N))
      StabC0=AvailC0*0.
      
      AvailN0=AvailC0/SCN
      StabN0=StabC0/SCN
  
      BA0=TC*0.025*0.2 #+np.zeros((mn,N))
      BD0=TC*0.025*0.8 #+np.zeros((mn,N))
      BAN0=BA0/BCNopt
      BDN0=BD0/BCNopt
  
      if OK_N_ENZ=='y':
        EFC0=BA0*0.01
        ESC0=BA0*0.01
        EFN0=BA0*0.01
        ESN0=BA0*0.01
  
      else:
        EFC0=BA0*0.01
        ESC0=BA0*0.01
        EFN0=BA0*0.
        ESN0=BA0*0.
  
      #HY test: how about initialize key pools with very small values
      BA0=1e-5;BD0=1e-5;BAN0=BA0/BCNopt;BDN0=BD0/BCNopt
      EFC0=0.;ESC0=0.;EFN0=0.;ESN0=0.
      AvailC0=0.;StabC0=0.;AvailN0=0.;StabN0=0.;
  
      SAC0=TC*0.05 #+np.zeros((1,N))
      SPC0=TC*0.45 #+np.zeros((1,N))
      SSC0=TC*0.50 #+np.zeros((1,N))
  
      SAN0=SAC0/SCN
      SPN0=SPC0/SCN
      SSN0=SSC0/SCN
  
      GL0=0. #+np.zeros((1,N)) #ACin+np.zeros((1,N))
  
      AvailCLr0=0. #+np.zeros((1,N))
      #AvailCLr0=ACin/(ACin+AvailC0)+np.zeros((1,N))
      AvailCSr0=1.-AvailCLr0
      StabCLr0=0. #+np.zeros((1,N))
      StabCSr0=1.-StabCLr0
      SACLr0=0. #+np.zeros((1,N))
      SACSr0=1.-SACLr0
      SSCLr0=0. #+np.zeros((1,N))
      SSCSr0=1.-SSCLr0
      SPCLr0=0. #+np.zeros((1,N))
      SPCSr0=1.-SPCLr0
      BALr0=0. #+np.zeros((mn,N))
      BASr0=1.- BALr0
      BDLr0=0. #+np.zeros((mn,N))
      BDSr0=1.- BDLr0
      EFCLr0=0. #+np.zeros((mn,N))
      EFCSr0=1.- EFCLr0
      EFNLr0=0. #+np.zeros((mn,N))
      EFNSr0=1.- EFNLr0
      #ELPLr0=0.+np.zeros((mn,N))
      #ELPSr0=1.- ELPLr0
      ESCLr0=0. #+np.zeros((mn,N))
      ESCSr0=1.- ESCLr0
      ESNLr0=0. #+np.zeros((mn,N))
      ESNSr0=1.- ESNLr0
      #ESPLr0=0.+np.zeros((mn,N))
      #ESPSr0=1.- ESPLr0
  
      CUEpre0=0.6
      NUEpre0=1.
  
      LMC0=LC0*0.5 #+np.zeros((1,N)) #*LM_fraction
      LSC0=LC0*0.5 #+np.zeros((1,N)) #*(1-LM_fraction);
      LLf0=LSC0*0.+0.5 #LC0*lignin/LSC0
      if LSC0==0: LLf0=0.
      
      LMN0=LMC0/50.
      LSN0=LSC0/150.
  
      if OK_restart=='y':
          GLtmp=np.load(restart_dir+'GL.npy')
          LMCtmp=np.load(restart_dir+'LMC.npy')
          LSCtmp=np.load(restart_dir+'LSC.npy')
          LMNtmp=np.load(restart_dir+'LMN.npy')
          LSNtmp=np.load(restart_dir+'LSN.npy')
          LLftmp=np.load(restart_dir+'LLf.npy')
          
          SACtmp=np.load(restart_dir+'SAC.npy')
          SSCtmp=np.load(restart_dir+'SSC.npy')
          SPCtmp=np.load(restart_dir+'SPC.npy')
          SANtmp=np.load(restart_dir+'SAN.npy')
          SSNtmp=np.load(restart_dir+'SSN.npy')
          SPNtmp=np.load(restart_dir+'SPN.npy')
  
          AvailCtmp=np.load(restart_dir+'AvailC.npy')
          StabCtmp=np.load(restart_dir+'StabC.npy')
          AvailNtmp=np.load(restart_dir+'AvailN.npy')
          StabNtmp=np.load(restart_dir+'StabN.npy')
  
          BAtmp=np.load(restart_dir+'BA.npy')
          BDtmp=np.load(restart_dir+'BD.npy')
          BANtmp=np.load(restart_dir+'BAN.npy')
          BDNtmp=np.load(restart_dir+'BDN.npy')
          EFCtmp=np.load(restart_dir+'EFC.npy')
          ESCtmp=np.load(restart_dir+'ESC.npy')
          EFNtmp=np.load(restart_dir+'EFN.npy')
          ESNtmp=np.load(restart_dir+'ESN.npy')   
  
          CUEpretmp=np.load(restart_dir+'CUEpre.npy')
          NUEpretmp=np.load(restart_dir+'NUEpre.npy')
  
          GL0=GLtmp[-1]
          LMC0=LMCtmp[-1]
          LSC0=LSCtmp[-1]
          LMN0=LMNtmp[-1]
          LSN0=LSNtmp[-1]
          LLf0=LLftmp[-1]
  
          SAC0=SACtmp[-1]
          SSC0=SSCtmp[-1]
          SPC0=SPCtmp[-1]
          SAN0=SANtmp[-1]
          SSN0=SSNtmp[-1]
          SPN0=SPNtmp[-1]
  
          AvailC0=AvailCtmp[-1]
          StabC0=StabCtmp[-1]
          AvailN0=AvailNtmp[-1]
          StabN0=StabNtmp[-1]
  
          BA0=BAtmp[-1]
          BD0=BDtmp[-1]
          BAN0=BANtmp[-1]
          BDN0=BDNtmp[-1]
          EFC0=EFCtmp[-1]
          ESC0=ESCtmp[-1]
          EFN0=EFNtmp[-1]
          ESN0=ESNtmp[-1]
          
          CUEpre0=CUEpretmp[-1]
          NUEpre0=NUEpretmp[-1]
  
      #time length to run
      yy1=0
      yy2=10

      #number of days in one year
      dd0=365
  
      depth=1. #m, the soil depth considered
      #only consider grid with all data available
      if not (lmaskLC[latn,lonn] and lmaskLCNin[latn,lonn] and lmaskBD[latn,lonn]):
        leafs=leafin[:,latn,lonn] #gC/m2/day
        roots=rootin[:,latn,lonn]
        woods=woodin[:,latn,lonn]
        Hsoils=Hsoilin[:,latn,lonn]
        Tsoils=Tsoilin[:,latn,lonn]
        SBD=SBDin[latn,lonn]
        CC=CCin[latn,lonn]
        leafCN=leafCNin[latn,lonn]
        rootCN=rootCNin[latn,lonn]
        woodCN=woodCNin[latn,lonn]
        if np.isnan(woodCN):woodCN=np.nanmean(woodCNin)
        LLfs=np.array([0.22,0.22,0.35])                          
        Ndep=Ndeps[latn,lonn]/(depth*SBD) #gN/kg soil/h
  
        #vegf=1.-vegmax[0,latn,lonn]/np.sum(vegmax[:,latn,lonn])
        vegf=np.sum(vegmax[1::,latn,lonn])
        if vegf<zerol:vegf=zerol
        print 'vegf=',vegf
        #allocate all the input to the top 1m (=depth) soil considering fraction of vegetation
        leafs=leafs/24./(SBD*depth*vegf)
        roots=roots/24./(SBD*depth*vegf)
        woods=woods/24./(SBD*depth*vegf)
  
        woods[np.isnan(woods)]=0.
  
        #assuming potential N uptaken by plants is equal to that in litter input
        Nplas=(np.sum(leafs)/leafCN+np.sum(roots)/rootCN+np.sum(woods)/woodCN)*npp_factor[:,latn,lonn]/np.sum(npp_factor[:,latn,lonn]) #+Ndep
        if np.sum(np.isnan(Nplas)):
          if np.sum(npp_factor[:,latn,lonn])==0:
            fid=file(outdir+'log','w')
            print 'pass because of zero input'
            print>>fid, 'pass because of zero input'
            fid.close()
            #no input for this grid, so pass this grid and continue simulation for the next grid
            continue                     
          else:
            print 'Error: nan in Nplas'
            print 'np.sum(leafs)/leafCN',np.sum(leafs)/leafCN,'np.sum(roots)/rootCN',np.sum(roots)/rootCN,'np.sum(woods)/woodCN',np.sum(woods)/woodCN,'npp_factor[:,latn,lonn]/np.sum(npp_factor[:,latn,lonn])',npp_factor[:,latn,lonn]/np.sum(npp_factor[:,latn,lonn])
            sys.exit()
      else:
        print 'masked grid'
        sys.exit()
  
      for yy in range(yy1,yy2,1):
          #print 'yy=',yy
          #To save disk space, only save output for given years
          #if yy<20000 and yy>=19900:
          #if 1:
          if (yy==19999 or yy==19998 or yy==19900 or yy==10000):
            #outdirtmp=outdir+str(np.mod(yy,100))+'/'
            outdirtmp=outdir+str(yy)+'/'
            if not os.path.exists(outdirtmp):
              os.makedirs(outdirtmp)
          #if yy<1000: Nuptakef=0.01

          t0=dd0*24/ts
          #initialization
          GL=np.zeros((t0+1))
          BA=np.zeros((t0+1));
          BD=np.zeros((t0+1));
          BAN=np.zeros((t0+1));
          BDN=np.zeros((t0+1));
          MCUE1=np.zeros((t0));
          CUEpre=np.zeros((t0+1));
          NUEpre=np.zeros((t0+1));
          EFC=np.zeros((t0+1));
          ESC=np.zeros((t0+1));
          EFN=np.zeros((t0+1));
          ESN=np.zeros((t0+1));
          #ELP=np.zeros((t0+1));
          #ESP=np.zeros((t0+1));
          EFCeq=np.zeros((t0));
          ESCeq=np.zeros((t0));
          EFNeq=np.zeros((t0));
          ESNeq=np.zeros((t0));
          #ELPeq=np.zeros((t0));
          #ESPeq=np.zeros((t0));
          LMC=np.zeros((t0+1));
          LSC=np.zeros((t0+1));
          LLf=np.zeros((t0+1));
          SAC=np.zeros((t0+1));
          SSC=np.zeros((t0+1));
          SPC=np.zeros((t0+1));
          AvailC=np.zeros((t0+1));
          StabC=np.zeros((t0+1));
          
          LMN=np.zeros((t0+1));
          LSN=np.zeros((t0+1));
          SAN=np.zeros((t0+1));
          SSN=np.zeros((t0+1));
          SPN=np.zeros((t0+1));
          AvailN=np.zeros((t0+1));
          StabN=np.zeros((t0+1));
  
          saturation_level=np.zeros((t0)); #
          gC=np.zeros((t0)); #growth rate at each time step
          gN=np.zeros((t0)); #growth rate at each time step
          #gP=np.zeros((t0));
          #g=np.zeros((t0));
          Rm=np.zeros((t0)); #maintenance respiration at each time step
          Rg=np.zeros((t0)); #growth respiration at each time step
          Rd=np.zeros((t0));
          Ro=np.zeros((t0));
          RC=np.zeros((t0));
          RL=np.zeros((t0));
          RS=np.zeros((t0));
  
          dGL=np.zeros((t0));
          dLMC=np.zeros((t0));
          dLMN=np.zeros((t0));
          #dLMP=np.zeros((t0));
          dLSC=np.zeros((t0));
          dLSN=np.zeros((t0));
          #dLSP=np.zeros((t0));
          dSAC=np.zeros((t0));
          dSAN=np.zeros((t0));
          #dSAP=np.zeros((t0));
          dSSC=np.zeros((t0));
          dSSN=np.zeros((t0));
          #dSSP=np.zeros((t0));
          dSPC=np.zeros((t0));
          dSPN=np.zeros((t0));
          #dSPP=np.zeros((t0));
          BAg=np.zeros((t0));
          BANg=np.zeros((t0));
          BAd=np.zeros((t0));
          Rma=np.zeros((t0));
          Rmd=np.zeros((t0));
          AvailCstab=np.zeros((t0));
          AvailCmob=np.zeros((t0));
          AvailCloss=np.zeros((t0));
          #AvailNstab=np.zeros((t0));
          #AvailNmob=np.zeros((t0));
          #AvailNloss=np.zeros((t0));
          #AvailPstab=np.zeros((t0));
          #AvailPmob=np.zeros((t0));
          #AvailPloss=np.zeros((t0));
          EFCg=np.zeros((t0));
          EFNg=np.zeros((t0));
          #ELPg=np.zeros((t0));
          ESCg=np.zeros((t0));
          ESNg=np.zeros((t0));
          #ESPg=np.zeros((t0));
          plantNuptakeout=np.zeros((t0))
          plantNuptakein=np.zeros((t0))
  
          AvailCLr=np.zeros((t0+1));
          AvailCSr=np.zeros((t0+1));
          StabCLr=np.zeros((t0+1));
          StabCSr=np.zeros((t0+1));
          SACLr=np.zeros((t0+1));
          SACSr=np.zeros((t0+1));
          SSCLr=np.zeros((t0+1));
          SSCSr=np.zeros((t0+1));
          SPCLr=np.zeros((t0+1));
          SPCSr=np.zeros((t0+1));
          BALr=np.zeros((t0+1))
          BASr=np.zeros((t0+1))
          BDLr=np.zeros((t0+1))
          BDSr=np.zeros((t0+1))
          EFCLr=np.zeros((t0+1))
          EFCSr=np.zeros((t0+1))
          EFNLr=np.zeros((t0+1))
          EFNSr=np.zeros((t0+1))
          #ELPLr=np.zeros((t0+1))
          #ELPSr=np.zeros((t0+1))
          ESCLr=np.zeros((t0+1))
          ESCSr=np.zeros((t0+1))
          ESNLr=np.zeros((t0+1))
          ESNSr=np.zeros((t0+1))
          #ESPLr=np.zeros((t0+1))
          #ESPSr=np.zeros((t0+1))
        
          if yy==yy1:
              BA[0]=BA0;
              BD[0]=BD0;
              BAN[0]=BAN0;
              BDN[0]=BDN0;
              EFC[0]=EFC0;
              ESC[0]=ESC0;
              EFN[0]=EFN0;
              ESN[0]=ESN0;
              #ELP[:,0]=ELP0;
              #ESP[:,0]=ESP0;
              GL[0]=GL0
              LMC[0]=LMC0;
              LSC[0]=LSC0;
              LLf[0]=LLf0
              SAC[0]=SAC0;
              SSC[0]=SSC0;
              SPC[0]=SPC0;
              AvailC[0]=AvailC0;
              StabC[0]=StabC0
           
              LMN[0]=LMN0;
              LSN[0]=LSN0;
              SAN[0]=SAN0;
              SSN[0]=SSN0;
              SPN[0]=SPN0;
              AvailN[0]=AvailN0;
              StabN[0]=StabN0
  
              AvailCLr[0]=AvailCLr0;
              AvailCSr[0]=AvailCSr0;
              StabCLr[0]=StabCLr0;
              StabCSr[0]=StabCSr0;
              SACLr[0]=SACLr0
              SACSr[0]=SACSr0
              SSCLr[0]=SSCLr0
              SSCSr[0]=SSCSr0
              SPCLr[0]=SPCLr0
              SPCSr[0]=SPCSr0
              BALr[0]=BALr0
              BASr[0]=BASr0
              BDLr[0]=BDLr0
              BDSr[0]=BDSr0
              EFCLr[0]=EFCLr0
              EFCSr[0]=EFCSr0
              EFNLr[0]=EFNLr0
              EFNSr[0]=EFNSr0
              #ELPLr[:,0]=ELPLr0
              #ELPSr[:,0]=ELPSr0
              ESCLr[0]=ESCLr0
              ESCSr[0]=ESCSr0
              ESNLr[0]=ESNLr0
              ESNSr[0]=ESNSr0
              #ESPLr[:,0]=ESPLr0
              #ESPSr[:,0]=ESPSr0
              CUEpre[0]=CUEpre0
              NUEpre[0]=NUEpre0
          else:
              BA[0]=BA_out;
              BD[0]=BD_out;
              BAN[0]=BAN_out;
              BDN[0]=BDN_out;
              EFC[0]=EFC_out;
              ESC[0]=ESC_out;
              EFN[0]=EFN_out;
              ESN[0]=ESN_out;
              GL[0]=GL_out
              LMC[0]=LMC_out;
              LSC[0]=LSC_out
              LLf[0]=LLf_out
              SAC[0]=SAC_out
              SSC[0]=SSC_out
              SPC[0]=SPC_out
              AvailC[0]=AvailC_out
              StabC[0]=StabC_out
              
              LMN[0]=LMN_out;
              LSN[0]=LSN_out
              SAN[0]=SAN_out
              SSN[0]=SSN_out
              SPN[0]=SPN_out
              AvailN[0]=AvailN_out
              StabN[0]=StabN_out
  
              ff=1.
              if OK_reset_Lr=='y':
                ff=0.
              
              AvailCLr[0]=AvailCLr_out*ff
              AvailCSr[0]=AvailCSr_out*ff
              StabCLr[0]=StabCLr_out*ff
              StabCSr[0]=StabCSr_out*ff
              SACLr[0]=SACLr_out*ff
              SACSr[0]=SACSr_out*ff
              SSCLr[0]=SSCLr_out*ff
              SSCSr[0]=SSCSr_out*ff
              SPCLr[0]=SPCLr_out*ff
              SPCSr[0]=SPCSr_out*ff
              BALr[0]=BALr_out*ff
              BASr[0]=BASr_out*ff
              BDLr[0]=BDLr_out*ff
              BDSr[0]=BDSr_out*ff
              EFCLr[0]=EFCLr_out*ff
              EFCSr[0]=EFCSr_out*ff
              EFNLr[0]=EFNLr_out*ff
              EFNSr[0]=EFNSr_out*ff
              ESCLr[0]=ESCLr_out*ff
              ESCSr[0]=ESCSr_out*ff
              ESNLr[0]=ESCLr_out*ff
              ESNSr[0]=ESCSr_out*ff
  
              CUEpre[0]=CUEpre_out
              NUEpre[0]=NUEpre_out
  
          times=1.
          Df=0.2  #dissolvable fraction of root litter
          tt=0
          for dd in range(dd0):
              H=Hsoils[dd]
              T=Tsoils[dd]
              Npla=Nplas[dd]
              ANin=Ndep+roots[dd]*times*Df/rootCN
              ACin=0.+roots[dd]*times*Df
              LCin=np.zeros(3)
              LCin[0]=leafs[dd]*times
              LCin[1]=roots[dd]*times*(1.-Df)
              LCin[2]=woods[dd]*times
              LCNin=np.zeros(3)
              LCNin[0]=leafCN
              LCNin[1]=rootCN
              LCNin[2]=woodCN
              LLfin=np.zeros(3)
              LLfin[0]=LLfs[0]
              LLfin[1]=LLfs[1]
              LLfin[2]=LLfs[2]
  
              #
              H0=H
              T0=T
              for t in range(24/ts):
                #LCin=1.6e-4 #1.6e-4 mg C/g soil/h from Wang et al., 2013
                if yy==yy1 and tt==0:
                  GL_in=GL0
                  LMC_in=LMC0
                  LSC_in=LSC0
                  LLf_in=LLf0
                  LMN_in=LMN0
                  LSN_in=LSN0
                  SAC_in=SAC0
                  SSC_in=SSC0
                  SPC_in=SPC0
                  SAN_in=SAN0
                  SSN_in=SSN0
                  SPN_in=SPN0
                  AvailC_in=AvailC0
               	  StabC_in=StabC0
                  AvailN_in=AvailN0
                  StabN_in=StabN0
                  BA_in=BA0
                  BD_in=BD0
                  BAN_in=BAN0
                  BDN_in=BDN0
                  EFC_in=EFC0
                  ESC_in=ESC0
                  EFN_in=EFN0
                  ESN_in=ESN0
                  AvailCLr_in=AvailCLr0
                  AvailCSr_in=AvailCSr0
                  StabCLr_in=StabCLr0
                  StabCSr_in=StabCSr0
                  SACLr_in=SACLr0
                  SACSr_in=SACSr0
                  SSCLr_in=SSCLr0
                  SSCSr_in=SSCSr0
                  SPCLr_in=SPCLr0
                  SPCSr_in=SPCSr0
                  BALr_in=BALr0
                  BASr_in=BASr0
                  BDLr_in=BDLr0
                  BDSr_in=BDSr0
                  EFCLr_in=EFCLr0
                  EFCSr_in=EFCSr0
                  ESCLr_in=ESCLr0
                  ESCSr_in=ESCSr0
                  EFNLr_in=EFNLr0
                  EFNSr_in=EFNSr0
                  ESNLr_in=ESNLr0
                  ESNSr_in=ESNSr0
                  CUEpre_in=CUEpre0
                  NUEpre_in=NUEpre0
                else:
                  GL_in=GL_out
                  LMC_in=LMC_out
                  LSC_in=LSC_out
                  LLf_in=LLf_out
                  LMN_in=LMN_out
                  LSN_in=LSN_out
                  SAC_in=SAC_out
                  SSC_in=SSC_out
                  SPC_in=SPC_out
                  SAN_in=SAN_out
                  SSN_in=SSN_out
                  SPN_in=SPN_out
                  AvailC_in=AvailC_out
                  StabC_in=StabC_out
                  AvailN_in=AvailN_out
                  StabN_in=StabN_out
                  BA_in=BA_out
                  BD_in=BD_out
                  BAN_in=BAN_out
                  BDN_in=BDN_out
                  EFC_in=EFC_out
                  ESC_in=ESC_out
                  EFN_in=EFN_out
                  ESN_in=ESN_out
                  AvailCLr_in=AvailCLr_out
                  AvailCSr_in=AvailCSr_out
                  StabCLr_in=StabCLr_out
                  StabCSr_in=StabCSr_out
                  SACLr_in=SACLr_out
                  SACSr_in=SACSr_out
                  SSCLr_in=SSCLr_out
                  SSCSr_in=SSCSr_out
                  SPCLr_in=SPCLr_out
                  SPCSr_in=SPCSr_out
                  BALr_in=BALr_out
                  BASr_in=BASr_out
                  BDLr_in=BDLr_out
                  BDSr_in=BDSr_out
                  EFCLr_in=EFCLr_out
                  EFCSr_in=EFCSr_out
                  ESCLr_in=ESCLr_out
                  ESCSr_in=ESCSr_out
                  EFNLr_in=EFNLr_out
                  EFNSr_in=EFNSr_out
                  ESNLr_in=ESNLr_out
                  ESNSr_in=ESNSr_out
                  CUEpre_in=CUEpre_out	
                  NUEpre_in=NUEpre_out
  
  
                GL_out,LMC_out,LMN_out,LSC_out,LSN_out,LLf_out,SAC_out,SAN_out,SSC_out,SSN_out,SPC_out,SPN_out,AvailC_out,AvailN_out,BA_out,BAN_out,BD_out,BDN_out,EFC_out,ESC_out,EFN_out,ESN_out,EFCeq_out,ESCeq_out,StabC_out,StabN_out,MCUE1_out,CUEpre_out,NUEpre_out,saturation_level_out,Rd_out,Ro_out,Rg_out,Rm_out,RC_out,gC_out,gN_out,AvailCLr_out,AvailCSr_out,StabCLr_out,StabCSr_out,SACLr_out,SACSr_out,SSCLr_out,SSCSr_out,SPCLr_out,SPCSr_out,BALr_out,BASr_out,BDLr_out,BDSr_out,EFCLr_out,EFCSr_out,ESCLr_out,ESCSr_out,EFNLr_out,EFNSr_out,ESNLr_out,ESNSr_out,dGL_out,dLMC_out,dLMN_out,dLSC_out,dLSN_out,dSAC_out,dSAN_out,dSSC_out,dSSN_out,dSPC_out,dSPN_out,BAg_out,BANg_out,BAd_out,Rma_out,Rmd_out,RL_out,RS_out,AvailCstab_out,AvailNstab_out,AvailCmob_out,AvailNmob_out,AvailCloss_out,AvailNloss_out,EFCg_out,ESCg_out,EFNg_out,ESNg_out,plantNuptake_out=microbe_growth(ts,OK_N,OK_N_ENZ,OK_absorb_N,K_CAE,VmaxUptake_refin,Kdin,dMFTref,Kein,Km_ref,b,dENZ,VmaxLMC,KMLC,Ea_stab,Ea_mob,EaGL,EaKM,EaLM,EaLS,VmaxSSC,KMSC,EaSS,StabCmax,KdesC,KabsC,CAE,Adj_GL,Adj_LS,Adj_SA,Adj_SP,Ke_min,Ea_uptake,Ea_main,EaSA,EaSP,KM_uptake,ELrin,pH0,T0,H0,pHs,Ts,Hs,pH0_dec,pHs_dec,KlossC,KlossN,KlossN2,LCin,LLfin,LCNin,ACin,ANin,GL_in,LMC_in,LMN_in,LSC_in,LSN_in,LLf_in,SAC_in,SAN_in,SSC_in,SSN_in,SPC_in,SPN_in,AvailC_in,AvailN_in,StabC_in,StabN_in,BA_in,BAN_in,BD_in,BDN_in,MFTtype,BCN,EFC_in,ESC_in,EFN_in,ESN_in,ECN,OK_control,OK_constant_CUE,OK_stab_C,T,H,pH,CC,mn,sC,sN,AvailCLr_in,AvailCSr_in,StabCLr_in,StabCSr_in,SACLr_in,SACSr_in,SSCLr_in,SSCSr_in,SPCLr_in,SPCSr_in,BALr_in,BASr_in,BDLr_in,BDSr_in,EFCLr_in,EFCSr_in,ESCLr_in,ESCSr_in,EFNLr_in,EFNSr_in,ESNLr_in,ESNSr_in,LMtoSS,LStoSS,SStoSP,SAtoSP,expc,efLS,efSA,efSS,efSP,KCN,CUEpre_in,NUEpre_in,KMED,OK_plant_uptake_N,Npla,Nuptakef,expuptake,BCNopt,BCNmin,BCNmax,T_ref,OK_fixed_dMFT,OK_fixed_dENZ,OK_fixed_KM,OK_fixed_Km,KMAED)
  
                BA[tt+1]=BA_out;
                BD[tt+1]=BD_out;
                BAN[tt+1]=BAN_out;
                BDN[tt+1]=BDN_out;
                EFC[tt+1]=EFC_out;
                ESC[tt+1]=ESC_out;
                EFN[tt+1]=EFN_out;
                ESN[tt+1]=ESN_out;
                GL[tt+1]=GL_out
                LMC[tt+1]=LMC_out;
                LSC[tt+1]=LSC_out
                LLf[tt+1]=LLf_out
                SAC[tt+1]=SAC_out
                SSC[tt+1]=SSC_out
                SPC[tt+1]=SPC_out
                AvailC[tt+1]=AvailC_out
                StabC[tt+1]=StabC_out
  
                LMN[tt+1]=LMN_out;
                LSN[tt+1]=LSN_out
                SAN[tt+1]=SAN_out
                SSN[tt+1]=SSN_out
                SPN[tt+1]=SPN_out
                AvailN[tt+1]=AvailN_out
                StabN[tt+1]=StabN_out
  
                AvailCLr[tt+1]=AvailCLr_out
                AvailCSr[tt+1]=AvailCSr_out
                StabCLr[tt+1]=StabCLr_out
                StabCSr[tt+1]=StabCSr_out;
                SACLr[tt+1]=SACLr_out
                SACSr[tt+1]=SACSr_out
                SSCLr[tt+1]=SSCLr_out
                SSCSr[tt+1]=SSCSr_out
                SPCLr[tt+1]=SPCLr_out
                SPCSr[tt+1]=SPCSr_out
                BALr[tt+1]=BALr_out
                BASr[tt+1]=BASr_out
                BDLr[tt+1]=BDLr_out
                BDSr[tt+1]=BDSr_out
                EFCLr[tt+1]=EFCLr_out
                EFCSr[tt+1]=EFCSr_out
                ESCLr[tt+1]=ESCLr_out
                ESCSr[tt+1]=ESCSr_out
                EFNLr[tt+1]=EFNLr_out
                EFNSr[tt+1]=EFNSr_out
                ESNLr[tt+1]=ESNLr_out
                ESNSr[tt+1]=ESNSr_out
                
                MCUE1[tt]=MCUE1_out #np.zeros((mn,t0,N));
                CUEpre[tt+1]=CUEpre_out #=np.zeros((mn,t0,N));
                NUEpre[tt+1]=NUEpre_out
                EFCeq[tt]=EFCeq_out #=np.zeros((t0,N));
                ESCeq[tt]=ESCeq_out #np.zeros((t0,N));
                saturation_level[tt]=saturation_level_out #=np.zeros((mn,t0,N)); #
                gC[tt]=gC_out #np.zeros((mn,t0,N)); #growth rate at each time step
                gN[tt]=gN_out
                #g[tt]=g_out #=np.zeros((mn,t0,N));
                Rm[tt]=Rm_out #=np.zeros((mn,t0,N)); #maintenance respiration at each time step
                Rg[tt]=Rg_out #=np.zeros((mn,t0,N)); #growth respiration at each time step
                Rd[tt]=Rd_out
                Ro[tt]=Ro_out #=np.zeros((mn,t0,N));
                RC[tt]=RC_out #=np.zeros((mn,t0,N));
                RL[tt]=RL_out #=np.zeros((mn,t0,N));
                RS[tt]=RS_out #=np.zeros((mn,t0,N));
  
                dLMN[tt]=dLMN_out #=np.zeros((t0,N));
                dLSN[tt]=dLSN_out #=np.zeros((t0,N));
                dSAN[tt]=dSAN_out #=np.zeros((t0,N));
                dSSN[tt]=dSSN_out #=np.zeros((t0,N));
                dSPN[tt]=dSPN_out #=np.zeros((t0,N));
  
                dGL[tt]=dGL_out #np.zeros((t0,N));
                dLMC[tt]=dLMC_out #=np.zeros((t0,N));
                dLSC[tt]=dLSC_out #=np.zeros((t0,N));
                dSAC[tt]=dSAC_out #=np.zeros((t0,N));
                dSSC[tt]=dSSC_out #=np.zeros((t0,N));
                dSPC[tt]=dSPC_out #=np.zeros((t0,N));
                BAg[tt]=BAg_out #=np.zeros((mn,t0,N));
                BANg[tt]=BANg_out
                BAd[tt]=BAd_out
                Rma[tt]=Rma_out #=np.zeros((mn,t0,N));
                Rmd[tt]=Rmd_out #=np.zeros((mn,t0,N));
                AvailCstab[tt]=AvailCstab_out #=np.zeros((t0,N));
                AvailCmob[tt]=AvailCmob_out #=np.zeros((t0,N));
                AvailCloss[tt]=AvailCloss_out #=np.zeros((t0,N));
                EFCg[tt]=EFCg_out #=np.zeros((mn,t0,N));
                ESCg[tt]=ESCg_out #=np.zeros((mn,t0,N));
                EFNg[tt]=EFNg_out #=np.zeros((mn,t0,N));
                ESNg[tt]=ESNg_out
                
                plantNuptakeout[tt]=plantNuptake_out
                plantNuptakein[tt]=Npla*ts
                tt=tt+1
  
          #if (yy<20000 and yy>=19998) or (yy<30000 and yy>=29900):
          if (yy==19999 or yy==19998 or yy==19900 or yy==10000):
          #if 1:
            np.save(outdirtmp+'yy.npy',yy)
            np.save(outdirtmp+'T.npy',T)
            np.save(outdirtmp+'LCin.npy',LCin)
  
            np.save(outdirtmp+'dLMC',dLMC)
            np.save(outdirtmp+'dLSC',dLSC)
            np.save(outdirtmp+'dSAC',dSAC)
            np.save(outdirtmp+'dSSC',dSSC)
            np.save(outdirtmp+'dSPC',dSPC)
  
            np.save(outdirtmp+'dLMN',dLMN)
            np.save(outdirtmp+'dLSN',dLSN)
            np.save(outdirtmp+'dSAN',dSAN)
            np.save(outdirtmp+'dSSN',dSSN)
            np.save(outdirtmp+'dSPN',dSPN)
  
            np.save(outdirtmp+'AvailCstab',AvailCstab)
            np.save(outdirtmp+'AvailCmob',AvailCmob)
            np.save(outdirtmp+'AvailCloss',AvailCloss)
  
            np.save(outdirtmp+'BA.npy',BA)
            np.save(outdirtmp+'BD.npy',BD)
            np.save(outdirtmp+'BAN.npy',BAN)
            np.save(outdirtmp+'BDN.npy',BDN)
            np.save(outdirtmp+'BAg.npy',BAg)
            np.save(outdirtmp+'BANg.npy',BANg)
            np.save(outdirtmp+'BAd.npy',BAd)
            np.save(outdirtmp+'EFC.npy',EFC)
            np.save(outdirtmp+'ESC.npy',ESC)
            if OK_N_ENZ=='y':
              np.save(outdirtmp+'EFN.npy',EFN)
              np.save(outdirtmp+'ESN.npy',ESN)
              np.save(outdirtmp+'EFNg.npy',EFNg)
              np.save(outdirtmp+'ESNg.npy',ESNg)
            np.save(outdirtmp+'EFCg.npy',EFCg)
            np.save(outdirtmp+'ESCg.npy',ESCg)        
  
            np.save(outdirtmp+'GL.npy',GL)
            np.save(outdirtmp+'LMC.npy',LMC)
            np.save(outdirtmp+'LSC.npy',LSC)
            np.save(outdirtmp+'LLf.npy',LLf)
  
            np.save(outdirtmp+'SAC.npy',SAC)
            np.save(outdirtmp+'SSC.npy',SSC)
            np.save(outdirtmp+'SPC.npy',SPC)
            np.save(outdirtmp+'AvailC.npy',AvailC)
            np.save(outdirtmp+'StabC.npy',StabC)
  
            np.save(outdirtmp+'LMN.npy',LMN)
            np.save(outdirtmp+'LSN.npy',LSN)
  
            np.save(outdirtmp+'SAN.npy',SAN)
            np.save(outdirtmp+'SSN.npy',SSN)
            np.save(outdirtmp+'SPN.npy',SPN)
            np.save(outdirtmp+'AvailN.npy',AvailN)
            np.save(outdirtmp+'StabN.npy',StabN)
  
            np.save(outdirtmp+'BALr.npy',BALr)
            np.save(outdirtmp+'BASr.npy',BASr)
            np.save(outdirtmp+'BDLr.npy',BDLr)
            np.save(outdirtmp+'BDSr.npy',BDSr)
  
            np.save(outdirtmp+'EFCLr.npy',EFCLr)
            np.save(outdirtmp+'EFCSr.npy',EFCSr)
            np.save(outdirtmp+'ESCLr.npy',ESCLr)
            np.save(outdirtmp+'ESCSr.npy',ESCSr)
  
            np.save(outdirtmp+'EFNLr.npy',EFNLr)
            np.save(outdirtmp+'EFNSr.npy',EFNSr)
            np.save(outdirtmp+'ESNLr.npy',ESNLr)
            np.save(outdirtmp+'ESNSr.npy',ESNSr)
  
            np.save(outdirtmp+'SACLr.npy',SACLr)
            np.save(outdirtmp+'SACSr.npy',SACSr)
            np.save(outdirtmp+'SSCLr.npy',SSCLr)
            np.save(outdirtmp+'SSCSr.npy',SSCSr)
            np.save(outdirtmp+'SPCLr.npy',SPCLr)
            np.save(outdirtmp+'SPCSr.npy',SPCSr)
  
            np.save(outdirtmp+'gC.npy',gC)
            np.save(outdirtmp+'gN.npy',gN)
            #np.save(outdirtmp+'g.npy',g)
            np.save(outdirtmp+'RL.npy',RL)
            np.save(outdirtmp+'RS.npy',RS)
            np.save(outdirtmp+'RC.npy',RC)
            np.save(outdirtmp+'Rm.npy',Rm)
            np.save(outdirtmp+'Rg.npy',Rg)
            np.save(outdirtmp+'Ro.npy',Ro)
            np.save(outdirtmp+'Rd.npy',Rd)
            np.save(outdirtmp+'Rma.npy',Rma)
            np.save(outdirtmp+'Rmd.npy',Rmd)
  
            np.save(outdirtmp+'AvailCLr.npy',AvailCLr)
            np.save(outdirtmp+'AvailCSr.npy',AvailCSr)
            np.save(outdirtmp+'StabCLr.npy',StabCLr)
            np.save(outdirtmp+'StabCSr.npy',StabCSr)
  
            np.save(outdirtmp+'saturation_level.npy',saturation_level)
  
            np.save(outdirtmp+'MCUE1.npy',MCUE1)
            np.save(outdirtmp+'CUEpre.npy',CUEpre)
            np.save(outdirtmp+'NUEpre.npy',NUEpre)
  
            np.save(outdirtmp+'plantNuptakeout',plantNuptakeout)
            np.save(outdirtmp+'plantNuptakein',plantNuptakein)
  
  
  endtime = time.time()
  print 'elapsed time:', endtime - starttime
