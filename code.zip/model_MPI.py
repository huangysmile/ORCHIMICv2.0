#!/usr/bin/env python
import numpy as np
from mpi4py import MPI
import sys
funcdir='/ccc/cont003/home/lsce/huangy/microbe/v2/bak/'
sys.path.append(funcdir)
import ORCHIMICv2 as model_func  # home-made

#Control flags
#simulations
OK_N='y'
RLRS_method=1
ts=24
OK_N_ENZ='y'
OK_absorb_N='y'

vers='v2'
if OK_N=='y':
    vers='CN_'+vers
elif OK_N=='n':
    vers='C_'+vers
vers=vers+'_m'+str(RLRS_method)

if OK_N_ENZ=='y':
  vers=vers+'_ECN'
elif OK_N_ENZ=='n':
  vers=vers+'_EC'

if OK_absorb_N=='y':
  vers=vers+'_AbsCN'
elif OK_absorb_N=='n':
  vers=vers+'_AbsC'

comm=MPI.COMM_WORLD
rank=comm.Get_rank()

print rank
#rank=0

cc1=000
cc2=800
cc3=16
gridids=np.arange(cc1,cc2,cc3)

start_gridid=gridids[rank]
N_gridid=cc3

model_func.run(vers,OK_N,OK_N_ENZ,OK_absorb_N,start_gridid,N_gridid,ts,RLRS_method)

comm.Barrier()

