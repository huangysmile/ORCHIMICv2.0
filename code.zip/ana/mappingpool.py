#!/usr/bin/env python
#PBS -N MFTs_optimize
#PBS -j oe
#PBS -q long
#PBS -o oe.MFT.Opt.v49
#PBS -l nodes=1:ppn=1

#from PythonTools import *
import numpy as np
#import pandas as pd
#import matplotlib.pyplot as plt
#from netCDF4 import Dataset
import os
#import copy as cp
#from mpl_toolkits.basemap import Basemap
#import matplotlib as mpl
import time
import sys
#from scipy.optimize import minimize

#This manuscript is used to integrate all grid simulations into a map matrix

starttime=time.time()

yy=10000   #The chosen year
vers='CN_v3.1_m1_ECN_AbsCN' #simulation name
#outdir='/home/surface3/yhuang/microbe/glotranp/ana/'+vers+'/'+str(yy)+'/'
outdir='/ccc/work/cont003/lsce/huangy/output/glotranp/ana/'+vers+'/'+str(yy)+'/'  #path for output
if not os.path.exists(outdir):
        os.makedirs(outdir)
print 'outdir=',outdir

#indir='/home/surface4/yhuang/microbe/glotranp/CN_'+vers+'_m1_ECN_AbsCN/cost1/0/'
#indir='/home/surface4/yhuang/microbe/glotranp/CN_'+vers+'_m1_ECN_AbsCN/'
#indir='/ccc/work/cont003/lsce/huangy/output/glotranp/CN_'+vers+'_m1_ECN_AbsCN/'
#indir='/ccc/work/cont003/lsce/huangy/output/glotranp/CN_'+vers+'_m1_ECN_AbsC/'
#indir='/ccc/scratch/cont003/gen6328/huangy/microbe/glotranp/CN_'+vers+'_m1_ECN_AbsC/'
indir='/ccc/scratch/cont003/gen6328/huangy/microbe/glotranp/'+vers+'/' #path for input


#other necessary input
indir0='/ccc/cont003/home/lsce/huangy/microbe/data/input/'
landpointdir=indir0+'/LCin/5deg/'
landpoint=np.load(landpointdir+'landpoint.npy')

a=np.load(indir0+'LCin5deg/LCin/Areas.npy')
c=np.load(indir0+'LCin5deg/LCin/Contfrac.npy')
lmask=np.load(indir0+'LCin5deg/LCin/lmask.npy')
a=np.ma.masked_array(a,lmask)
c=np.ma.masked_array(c,lmask)

BD=np.load(indir0+'LCin/soil_info/5deg/BD.npy')
BDmask=np.load(indir0+'LCin/soil_info/5deg/BDmask.npy')
BDori=np.load(indir0+'LCin/soil_info/5deg/BDori.npy')
BD=np.ma.masked_array(BD,BDmask)
BDori=np.ma.masked_array(BDori,BDmask)

#initialize variables
land=np.zeros((36,72))*np.nan
BACs=np.zeros((36,72))*np.nan
BDCs=np.zeros((36,72))*np.nan
SACs=np.zeros((36,72))*np.nan
SSCs=np.zeros((36,72))*np.nan
SPCs=np.zeros((36,72))*np.nan
AvailCs=np.zeros((36,72))*np.nan
AdsorbCs=np.zeros((36,72))*np.nan
EFCs=np.zeros((36,72))*np.nan
ELNs=np.zeros((36,72))*np.nan
ESCs=np.zeros((36,72))*np.nan
ESNs=np.zeros((36,72))*np.nan
LMCs=np.zeros((36,72))*np.nan
LSCs=np.zeros((36,72))*np.nan

BANs=np.zeros((36,72))*np.nan
BDNs=np.zeros((36,72))*np.nan
SANs=np.zeros((36,72))*np.nan
SSNs=np.zeros((36,72))*np.nan
SPNs=np.zeros((36,72))*np.nan
AvailNs=np.zeros((36,72))*np.nan
AdsorbNs=np.zeros((36,72))*np.nan
LMNs=np.zeros((36,72))*np.nan
LSNs=np.zeros((36,72))*np.nan

dd1=0
dd2=365
ECN=3. #C/N ratio of enzymes, prescribed parameter
for i in np.arange(landpoint.shape[0]):
  print i
  ilat=int(landpoint[i,0]); ilon=int(landpoint[i,1])
  indirtmp=indir+str(i)+'/'+str(yy)+'/'
  if not os.path.exists(indirtmp):
    print 'Follwoing dir does not exit:',indirtmp
    continue
  land[ilat,ilon]=1
  BAC=np.load(indirtmp+'BA.npy')
  BDC=np.load(indirtmp+'BD.npy')
  EFC=np.load(indirtmp+'EFC.npy')
  ESC=np.load(indirtmp+'ESC.npy')
  ELN=np.load(indirtmp+'ELN.npy')
  ESN=np.load(indirtmp+'ESN.npy')
  SAC=np.load(indirtmp+'SAC.npy')
  SSC=np.load(indirtmp+'SSC.npy')
  SPC=np.load(indirtmp+'SPC.npy')
  AvailC=np.load(indirtmp+'AvailC.npy')
  StabC=np.load(indirtmp+'AvailN.npy')
  LMC=np.load(indirtmp+'LMN.npy')
  LSC=np.load(indirtmp+'LSN.npy')
  #sys.exit()

  BAN=np.load(indirtmp+'BAN.npy')
  BDN=np.load(indirtmp+'BDN.npy')
  SAN=np.load(indirtmp+'SAN.npy')
  SSN=np.load(indirtmp+'SSN.npy')
  SPN=np.load(indirtmp+'SPN.npy')
  AvailN=np.load(indirtmp+'AvailN.npy')
  StabN=np.load(indirtmp+'StabN.npy')
  LMN=np.load(indirtmp+'LMN.npy')
  LSN=np.load(indirtmp+'LSN.npy')

  BACs[ilat,ilon]=np.mean(BAC[dd1:dd2])
  BDCs[ilat,ilon]=np.mean(BDC[dd1:dd2])
  EFCs[ilat,ilon]=np.mean(EFC[dd1:dd2])
  ESCs[ilat,ilon]=np.mean(ESC[dd1:dd2])
  ELNs[ilat,ilon]=np.mean(ELN[dd1:dd2])
  ESNs[ilat,ilon]=np.mean(ESN[dd1:dd2])
  SACs[ilat,ilon]=np.mean(SAC[dd1:dd2])
  SSCs[ilat,ilon]=np.mean(SSC[dd1:dd2])
  SPCs[ilat,ilon]=np.mean(SPC[dd1:dd2])
  AvailCs[ilat,ilon]=np.mean(AvailC[dd1:dd2])
  AdsorbCs[ilat,ilon]=np.mean(StabC[dd1:dd2])
  LMCs[ilat,ilon]=np.mean(LMC[dd1:dd2])
  LSCs[ilat,ilon]=np.mean(LSC[dd1:dd2])

  BANs[ilat,ilon]=np.mean(BAN[dd1:dd2])
  BDNs[ilat,ilon]=np.mean(BDN[dd1:dd2])
  SANs[ilat,ilon]=np.mean(SAN[dd1:dd2])
  SSNs[ilat,ilon]=np.mean(SSN[dd1:dd2])
  SPNs[ilat,ilon]=np.mean(SPN[dd1:dd2])
  AvailNs[ilat,ilon]=np.mean(AvailN[dd1:dd2])
  AdsorbNs[ilat,ilon]=np.mean(StabN[dd1:dd2])
  LMNs[ilat,ilon]=np.mean(LMN[dd1:dd2])
  LSNs[ilat,ilon]=np.mean(LSN[dd1:dd2])
  #sys.exit()

BC=BACs+BDCs
BN=BANs+BDNs
BCN=BC/BN
BACr=BACs/BC
BANr=BANs/BN
SC=SACs+SSCs+SPCs+BACs+BDCs+EFCs+ESCs+ELNs+ESNs+AvailCs+AdsorbCs
SN=SANs+SSNs+SPNs+BANs+BDNs+(EFCs+ESCs+ELNs+ESNs)/ECN+AvailNs+AdsorbNs
SCN=SC/SN
BCr=BC/SC
BNr=BN/SN
EC=EFCs+ESCs+ELNs+ESNs
EN=EC/ECN
ECr=EC/BC
ENr=EN/BN

#BC=BC*BD
#BN=BN*BD
#SC=SC*BD
#SN=SN*BD
#EC=EC*BD
#EN=EN*BD

np.save(outdir+'BACs.npy',BACs)
np.save(outdir+'BDCs.npy',BDCs)
np.save(outdir+'EFCs.npy',EFCs)
np.save(outdir+'ESCs.npy',ESCs)
np.save(outdir+'ELNCs.npy',ELNs)
np.save(outdir+'ESNs.npy',ESNs)
np.save(outdir+'SACs.npy',SACs)
np.save(outdir+'SSCs.npy',SSCs)
np.save(outdir+'SPCs.npy',SPCs)
np.save(outdir+'AvailCs.npy',AvailCs)
np.save(outdir+'AdsorbCs.npy',AdsorbCs)
np.save(outdir+'LMCs.npy',LMCs)
np.save(outdir+'LSCs.npy',LSCs)

np.save(outdir+'BANs.npy',BANs)
np.save(outdir+'BDNs.npy',BDNs)
np.save(outdir+'SANs.npy',SANs)
np.save(outdir+'SSNs.npy',SSNs)
np.save(outdir+'SPNs.npy',SPNs)
np.save(outdir+'AvailNs.npy',AvailNs)
np.save(outdir+'AdsorbNs.npy',AdsorbNs)
np.save(outdir+'LMNs.npy',LMNs)
np.save(outdir+'LSNs.npy',LSNs)

np.save(outdir+'BC.npy',BC)
np.save(outdir+'BN.npy',BN)
np.save(outdir+'BCN.npy',BCN)
np.save(outdir+'BACr.npy',BACr)
np.save(outdir+'BANr.npy',BANr)
np.save(outdir+'SC.npy',SC)
np.save(outdir+'SN.npy',SN)
np.save(outdir+'SCN.npy',SCN)
np.save(outdir+'BCr.npy',BCr)
np.save(outdir+'BNr.npy',BNr)
np.save(outdir+'EC.npy',EC)
np.save(outdir+'EN.npy',EN)
np.save(outdir+'ECr.npy',ECr)
np.save(outdir+'ENr.npy',ENr)


endtime = time.time()
print 'elapsed time:', endtime - starttime
