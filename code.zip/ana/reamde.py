First run mappingpool.py to prepare data
Then, run mapping_MIC to get figures

